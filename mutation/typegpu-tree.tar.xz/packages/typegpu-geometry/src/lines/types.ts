import type { Infer } from 'typegpu/data';
import { f32, struct, vec2f } from 'typegpu/data';

export type LineControlPoint = Infer<typeof LineControlPoint>;
export const LineControlPoint = struct({
  position: vec2f,
  radius: f32,
});

export type LineSegmentOutput = Infer<typeof LineSegmentOutput>;
export const LineSegmentOutput = struct({
  vertexPosition: vec2f,
  /** Homogeneous coordinate for scaling surface values */
  w: f32,
});

export type JoinInput = Infer<typeof JoinInput>;
export const JoinInput = struct({
  C: LineControlPoint,
  v: vec2f,
  d: vec2f,
  fw: vec2f,
  cross: vec2f,
  start: vec2f,
  end: vec2f,
});
