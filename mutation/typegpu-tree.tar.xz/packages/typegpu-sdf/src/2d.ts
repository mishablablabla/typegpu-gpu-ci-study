import { tgpu } from 'typegpu';
import { f32, type v2f, vec2f, vec3f } from 'typegpu/data';
import {
  abs,
  acos,
  clamp,
  cos,
  distance,
  dot,
  length,
  max,
  min,
  pow,
  saturate,
  sign,
  sin,
  sqrt,
} from 'typegpu/std';

/**
 * Signed distance function for a disk (filled circle)
 * @param point Point to evaluate
 * @param radius Radius of the disk
 */
export const sdDisk = tgpu.fn(
  [vec2f, f32],
  f32,
)((point, radius) => {
  return length(point) - radius;
});

/**
 * Signed distance function for a 2d box (rectangle)
 * @param point Point to evaluate
 * @param size Half-dimensions of the box
 */
export const sdBox2d = tgpu.fn(
  [vec2f, vec2f],
  f32,
)((point, size) => {
  'use gpu';
  const d = abs(point) - size;
  return length(max(d, vec2f(0))) + min(max(d.x, d.y), 0);
});

/**
 * Signed distance function for a rounded 2d box
 * @param point Point to evaluate
 * @param size Half-dimensions of the box
 * @param cornerRadius Box corner radius
 */
export const sdRoundedBox2d = tgpu.fn(
  [vec2f, vec2f, f32],
  f32,
)((point, size, cornerRadius) => {
  'use gpu';
  const d = abs(point) - size + vec2f(cornerRadius);
  return length(max(d, vec2f(0))) + min(max(d.x, d.y), 0) - cornerRadius;
});

/**
 * Signed distance function for a line segment
 * @param point Point to evaluate
 * @param A First endpoint of the line
 * @param B Second endpoint of the line
 */
export const sdLine = tgpu.fn(
  [vec2f, vec2f, vec2f],
  f32,
)((point, A, B) => {
  'use gpu';
  const pa = point - A;
  const ba = B - A;
  const h = max(0, min(1, dot(pa, ba) / dot(ba, ba)));
  return distance(pa, ba * h);
});

const dot2 = (v: v2f) => {
  'use gpu';
  return dot(v, v);
};

/**
 * Signed distance function for a quadratic Bezier curve
 * @param point Point to evaluate
 * @param A First control point of the Bezier curve
 * @param B Second control point of the Bezier curve
 * @param C Third control point of the Bezier curve
 */
export const sdBezier = tgpu.fn(
  [vec2f, vec2f, vec2f, vec2f],
  f32,
)((point, A, B, C) => {
  'use gpu';
  const a = B - A;
  const b = A - B * 2 + C;
  const c = a * 2;
  const d = A - point;

  const dotB = max(dot(b, b), 0.0001);
  const kk = 1 / dotB;
  const kx = kk * dot(a, b);
  const ky = (kk * (f32(2) * dot(a, a) + dot(d, b))) / 3;
  const kz = kk * dot(d, a);

  let res = f32(0);
  const p = ky - kx * kx;
  const p3 = p * p * p;
  const q = kx * (2 * kx * kx - 3 * ky) + kz;
  let h = q * q + 4 * p3;

  if (h >= 0.0) {
    h = sqrt(h);
    const x = (vec2f(h, -h) - q) * 0.5;
    const uv = sign(x) * pow(abs(x), vec2f(1 / 3));
    const t = saturate(uv.x + uv.y - kx);
    res = dot2(d + (c + b * t) * t);
  } else {
    const z = sqrt(-p);
    const v = acos(q / (p * z * 2)) / 3;
    const m = cos(v);
    const n = sin(v) * 1.732050808; // sqrt(3)
    const t = saturate(vec3f(m + m, -n - m, n - m) * z - kx);

    res = min(dot2(d + (c + b * t.x) * t.x), dot2(d + (c + b * t.y) * t.y));
  }

  return sqrt(res);
});

const cross = (a: v2f, b: v2f) => {
  'use gpu';
  return a.x * b.y - a.y * b.x;
};

/**
 * A fast approximation of the signed distance function for a quadratic Bezier curve
 * @param point Point to evaluate
 * @param A First control point of the Bezier curve
 * @param B Second control point of the Bezier curve
 * @param C Third control point of the Bezier curve
 */
export const sdBezierApprox = tgpu.fn(
  [vec2f, vec2f, vec2f, vec2f],
  f32,
)((point, A, B, C) => {
  'use gpu';
  const i = A - C;
  const j = C - B;
  const k = B - A;
  const w = j - k;

  const v0 = A - point;
  const v1 = B - point;
  const v2 = C - point;

  const x = cross(v0, v2);
  const y = cross(v1, v0);
  const z = cross(v2, v1);

  const s = (j * y + k * z) * 2 - i * x;

  const r = (y * z - x * x * 0.25) / dot2(s);
  const t = saturate((0.5 * x + y + r * dot(s, w)) / (x + y + z));

  const d = v0 + (2 * k + w * t) * t;
  return length(d);
});

/**
 * Computes the signed distance field for a pie shape (circular sector).
 *
 * @param point - The point to evaluate, in 2D space
 * @param sc - The sine/cosine of the pie's half-angle (`d.vec2f(std.sin(angle/2), std.cos(angle/2))`)
 * @param radius - The radius of the pie
 */
export const sdPie = tgpu.fn(
  [vec2f, vec2f, f32],
  f32,
)((point, sc, radius) => {
  'use gpu';
  const p_w = vec2f(point);
  p_w.x = abs(point.x);
  const l = length(p_w) - radius;
  const m = distance(p_w, sc * clamp(dot(p_w, sc), 0, radius));
  return max(l, m * sign(sc.y * p_w.x - sc.x * p_w.y));
});

/**
 * Distance function for a zero-width circular arc.
 * The circle is centered at the origin. The arc's midpoint is at `(0, radius)`, and it extends
 * by `angle / 2` to each side of it, so it opens towards negative Y.
 * Since the arc has no width, no point is ever inside it; subtract a stroke half-width from
 * the result to get a solid shape (e.g. `sdArc(p, sc, radius) - thickness`).
 *
 * @param position Point to evaluate, relative to the circle's center
 * @param sc Sine and cosine of the arc's half-angle: `vec2f(sin(angle / 2), cos(angle / 2))`,
 * where `angle` is the full sweep in radians, from 0 to 2 * PI
 * @param radius Radius of the arc's centerline (non-negative)
 * @returns Unsigned distance to the arc (non-negative), zero only on the arc itself
 */
export const sdArc = tgpu.fn(
  [vec2f, vec2f, f32],
  f32,
)((position, sc, radius) => {
  'use gpu';
  const pos = vec2f(abs(position.x), position.y);
  if (sc.y * pos.x > sc.x * pos.y) {
    return length(pos - sc * radius);
  }
  return abs(length(pos) - radius);
});

/**
 * Signed distance function for a regular hexagon with flat edges at the top and bottom.
 *
 * @param point Point to evaluate, relative to the hexagon's center
 * @param radius Inradius: distance from the center to the middle of each edge (non-negative)
 * @returns Negative inside the hexagon, zero on its edge, positive outside
 */
export const sdHexagon2d = tgpu.fn(
  [vec2f, f32],
  f32,
)((point, radius) => {
  'use gpu';
  // (-cos(pi / 6), sin(pi / 6), tan(pi / 6))
  const k = vec3f(-0.866025404, 0.5, 0.577350269);
  let p = abs(point);
  p -= k.xy * (2 * min(dot(k.xy, p), 0));
  p -= vec2f(clamp(p.x, -k.z * radius, k.z * radius), radius);
  return length(p) * sign(p.y);
});

/**
 * Signed distance function for a regular hexagon, together with its gradient.
 * Same shape as {@link sdHexagon2d}.
 *
 * @param point Point to evaluate, relative to the hexagon's center
 * @param radius Inradius: distance from the center to the middle of each edge (non-negative)
 * @returns vec3f(distance, gradient.x, gradient.y), where the gradient is the unit vector
 * pointing in the direction of increasing signed distance. The gradient is undefined
 * at points exactly on the edge.
 */
export const sdgHexagon2d = tgpu.fn(
  [vec2f, f32],
  vec3f,
)((point, radius) => {
  'use gpu';
  // (-cos(pi / 6), sin(pi / 6), tan(pi / 6))
  const k = vec3f(-0.866025404, 0.5, 0.577350269);
  const s = sign(point);
  let p = abs(point);
  const w = dot(k.xy, p);
  p -= k.xy * (2 * min(w, 0));
  p -= vec2f(clamp(p.x, -k.z * radius, k.z * radius), radius);
  const d = length(p) * sign(p.y);
  // if the point was reflected across the slanted edge, reflect the gradient back
  const g = w < 0 ? vec2f(-k.y * p.x - k.x * p.y, -k.x * p.x + k.y * p.y) : vec2f(p);
  return vec3f(d, (s * g) / d);
});
