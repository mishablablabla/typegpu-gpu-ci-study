import { type ResolvedSnippet, snip } from '../../data/snippet.ts';
import { Void } from '../../data/wgslTypes.ts';
import { $internal, $resolve } from '../../shared/symbols.ts';
import type { ResolutionCtx, SelfResolvable } from '../../types.ts';
import { type ExternalMap, replaceExternalsInWgsl } from '../resolve/externals.ts';

// ----------
// Public API
// ----------

/**
 * Extra declaration that shall be included in final WGSL code,
 * when resolving objects that use it.
 */
export interface TgpuDeclare {
  $uses(dependencyMap: Record<string, unknown>): this;
}

/**
 * Allows defining extra declarations that shall be included in the final WGSL code,
 * when resolving objects that use them.
 *
 * Using this API is generally discouraged, as it shouldn't be necessary in any common scenario.
 * It was developed to ensure full compatibility of TypeGPU programs with current and future versions of WGSL.
 */
export function declare(declaration: string): TgpuDeclare {
  return new TgpuDeclareImpl(declaration);
}

// --------------
// Implementation
// --------------

export class TgpuDeclareImpl implements TgpuDeclare, SelfResolvable {
  readonly [$internal] = true;
  #externals: ExternalMap | undefined;
  #declaration: string;

  constructor(declaration: string) {
    this.#declaration = declaration;
  }

  $uses(dependencyMap: Record<string, unknown>): this {
    if (this.#externals !== undefined) {
      throw new Error(
        "Cannot call '$uses' multiple times. If you wish to override dependencies, use slots or accessors instead.",
      );
    }
    this.#externals = dependencyMap;
    return this;
  }

  [$resolve](ctx: ResolutionCtx): ResolvedSnippet {
    const replacedDeclaration = replaceExternalsInWgsl(
      ctx,
      this.#externals ?? {},
      this.#declaration,
    );

    ctx.addDeclaration(replacedDeclaration);
    return snip('', Void, /* origin */ 'constant');
  }

  toString() {
    return `declare: ${this.#declaration}`;
  }
}
