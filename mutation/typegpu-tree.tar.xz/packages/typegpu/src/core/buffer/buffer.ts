import { getCompiledWriter } from '../../data/compiledIO.ts';
import type { AnyData } from '../../data/dataTypes.ts';
import { convertPartialToPatch, getPatchInstructions } from '../../data/partialIO.ts';
import { sizeOf } from '../../data/sizeOf.ts';
import { roundUp } from '../../mathUtils.ts';
import type { BaseData } from '../../data/wgslTypes.ts';
import { isWgslData } from '../../data/wgslTypes.ts';
import type { StorageFlag } from '../../extension.ts';
import type { TgpuNamable } from '../../shared/meta.ts';
import { getName, setName } from '../../shared/meta.ts';
import type {
  Infer,
  InferInput,
  InferPatch,
  InferPartial,
  IsValidIndexSchema,
  IsValidStorageSchema,
  IsValidUniformSchema,
  IsValidVertexSchema,
  MemIdentity,
} from '../../shared/repr.ts';
import type { TgpuDeviceOwningSoul } from '../../shared/soul.ts';
import { $internal, $soul } from '../../shared/symbols.ts';
import type { Prettify, UnionToIntersection } from '../../shared/utilityTypes.ts';
import { isGPUBuffer } from '../../types.ts';
import type { TgpuCommandEncoder } from '../commandEncoder/commandEncoder.ts';
import type { ExperimentalTgpuRoot } from '../root/rootTypes.ts';
import { calculateOffsets, readFromArrayBuffer, writeToArrayBuffer } from '../../data/dataIO.ts';
import { patchArrayBuffer } from '../../data/partialIO.ts';
import {
  mutable,
  readonly,
  uniform,
  type TgpuMutable,
  type TgpuReadonly,
  type TgpuUniform,
} from './bufferBinding.ts';
import { warnIfNotUniformAligned } from '../pipeline/webgpuLimitations.ts';

// ----------
// Public API
// ----------

export interface UniformFlag {
  usableAsUniform: true;
}

/**
 * @deprecated Use UniformFlag instead.
 */
export type Uniform = UniformFlag;

export interface VertexFlag {
  usableAsVertex: true;
}

export interface IndexFlag {
  usableAsIndex: true;
}

export interface IndirectFlag {
  usableAsIndirect: true;
}

/**
 * @deprecated Use VertexFlag instead.
 */
export type Vertex = VertexFlag;

export type TgpuStorageBuffer<T extends BaseData> = TgpuBuffer<T> & StorageFlag;
export type TgpuUniformBuffer<T extends BaseData> = TgpuBuffer<T> & UniformFlag;
export type TgpuVertexBuffer<T extends BaseData> = TgpuBuffer<T> & VertexFlag;
export type TgpuIndexBuffer<T extends BaseData> = TgpuBuffer<T> & IndexFlag;

export type UsageLiteral = 'uniform' | 'storage' | 'vertex' | 'index' | 'indirect';

export interface TgpuBufferSoul<TData extends BaseData = BaseData> extends TgpuDeviceOwningSoul<
  'buffer',
  GPUBuffer
> {
  readonly dataType: TData;
  flags: GPUBufferUsageFlags;
  readonly usages: UsageLiteral[];
}

type LiteralToUsageType<T extends UsageLiteral> = T extends 'uniform'
  ? UniformFlag
  : T extends 'storage'
    ? StorageFlag
    : T extends 'vertex'
      ? VertexFlag
      : T extends 'index'
        ? IndexFlag
        : T extends 'indirect'
          ? IndirectFlag
          : never;

type ViewUsages<TBuffer extends TgpuBuffer<BaseData>> =
  | (boolean extends TBuffer['usableAsUniform'] ? never : 'uniform')
  | (boolean extends TBuffer['usableAsStorage'] ? never : 'readonly' | 'mutable');

type UsageTypeToBufferBinding<TData extends BaseData> = {
  uniform: TgpuUniform<TData>;
  mutable: TgpuMutable<TData>;
  readonly: TgpuReadonly<TData>;
};

const usageToUsageConstructor = { uniform, mutable, readonly };

/**
 * Done as an object to later Prettify it
 */
type InnerValidUsagesFor<T> = {
  usage:
    | (IsValidStorageSchema<T> extends true ? 'storage' : never)
    | (IsValidUniformSchema<T> extends true ? 'uniform' : never)
    | (IsValidVertexSchema<T> extends true ? 'vertex' : never)
    | (IsValidIndexSchema<T> extends true ? 'index' : never)
    // there is no way to check at the type level if a buffer can be used as indirect (size >= 12 bytes)
    | 'indirect';
};

export type ValidUsagesFor<T> = InnerValidUsagesFor<T>['usage'];

export type BufferWriteOptions = {
  startOffset?: number;
  endOffset?: number;
};

export type BufferInitCallback<TData extends BaseData> = (buffer: TgpuBuffer<TData>) => void;
export type BufferInitialData<TData extends BaseData> =
  | InferInput<TData>
  | BufferInitCallback<TData>;

export interface TgpuBuffer<TData extends BaseData> extends TgpuNamable {
  readonly [$internal]: {
    readonly root: ExperimentalTgpuRoot;
    readonly materialize: () => GPUBuffer;
  };
  readonly [$soul]: TgpuBufferSoul<TData>;
  readonly resourceType: 'buffer';
  readonly dataType: TData;
  readonly initial?: InferInput<TData> | undefined;
  readonly arrayBuffer: ArrayBuffer;

  readonly buffer: GPUBuffer;
  readonly destroyed: boolean;

  usableAsUniform: boolean;
  usableAsStorage: boolean;
  usableAsVertex: boolean;
  usableAsIndex: boolean;
  usableAsIndirect: boolean;

  $usage<
    T extends [
      Prettify<InnerValidUsagesFor<TData>>['usage'],
      ...Prettify<InnerValidUsagesFor<TData>>['usage'][],
    ],
  >(
    ...usages: T
  ): this & UnionToIntersection<LiteralToUsageType<T[number]>>;
  $addFlags(flags: GPUBufferUsageFlags): this;

  as<T extends ViewUsages<this>>(usage: T): UsageTypeToBufferBinding<TData>[T];

  compileWriter(): void;
  write(data: InferInput<TData>, options?: BufferWriteOptions): void;
  write(data: ArrayBuffer, options?: BufferWriteOptions): void;
  /** @deprecated Use {@link patch} instead. */
  writePartial(data: InferPartial<TData>): void;
  patch(data: InferPatch<TData>): void;
  clear(encoder?: TgpuCommandEncoder): void;
  copyFrom(srcBuffer: TgpuBuffer<MemIdentity<TData>>, encoder?: TgpuCommandEncoder): void;
  read(): Promise<Infer<TData>>;
  destroy(): void;
  toString(): string;
}

/**
 * WebGPU requires buffer sizes, writes, copies and mappings
 * to be multiples of 4 bytes. Schemas like `arrayOf(u16, 3)` can have a smaller logical
 * size, so the underlying allocation gets padded up to the next multiple of 4.
 */
function physicalSizeOf(schema: BaseData): number {
  return roundUp(sizeOf(schema), 4);
}

export function INTERNAL_createBuffer<TData extends AnyData>(
  group: ExperimentalTgpuRoot,
  typeSchema: TData,
  initialOrBuffer?: BufferInitialData<TData> | GPUBuffer,
): TgpuBuffer<TData> {
  if (!isWgslData(typeSchema)) {
    return new TgpuBufferImpl(group, typeSchema, initialOrBuffer, ['storage', 'uniform']);
  }

  return new TgpuBufferImpl(group, typeSchema, initialOrBuffer);
}

export function INTERNAL_applyBufferUsages(
  buffer: TgpuBuffer<BaseData>,
  usages: UsageLiteral[],
): void {
  if (usages.length > 0) {
    (buffer as TgpuBufferImpl<BaseData>).$usage(...usages);
  }
}

// --------------
// Implementation
// --------------
class TgpuBufferImpl<TData extends BaseData> implements TgpuBuffer<TData> {
  readonly [$internal]: {
    readonly root: ExperimentalTgpuRoot;
    readonly materialize: () => GPUBuffer;
  };
  readonly [$soul]: TgpuBufferSoul<TData>;
  readonly resourceType = 'buffer';

  #ownBuffer: boolean;
  #destroyed = false;
  #internalBuffer: ArrayBuffer | undefined;

  get #hostBuffer(): ArrayBuffer {
    return (this.#internalBuffer ??= new ArrayBuffer(physicalSizeOf(this.dataType)));
  }
  #mappedRange: ArrayBuffer | undefined;
  #initialCallback: BufferInitCallback<TData> | undefined;
  readonly #disallowedUsages: UsageLiteral[] | undefined;

  readonly initial: InferInput<TData> | undefined;

  usableAsUniform = false;
  usableAsStorage = false;
  usableAsVertex = false;
  usableAsIndex = false;
  usableAsIndirect = false;

  constructor(
    root: ExperimentalTgpuRoot,
    dataType: TData,
    initialOrBuffer?: BufferInitialData<TData> | GPUBuffer,
    disallowedUsages?: UsageLiteral[],
  ) {
    this[$soul] = {
      type: 'buffer',
      device: root.device,
      dataType,
      flags: GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC,
      usages: [],
      raw: undefined,
      label: undefined,
    };
    this.#disallowedUsages = disallowedUsages;
    if (isGPUBuffer(initialOrBuffer)) {
      this.#ownBuffer = false;
      this[$soul].raw = initialOrBuffer;
    } else {
      this.#ownBuffer = true;
      if (typeof initialOrBuffer === 'function') {
        this.#initialCallback = initialOrBuffer as BufferInitCallback<TData>;
      } else {
        this.initial = initialOrBuffer;
      }
    }
    this[$internal] = {
      root,
      materialize: () => {
        if (this.#destroyed) {
          throw new Error('This buffer has been destroyed');
        }

        const soul = this[$soul];
        if (!soul.raw) {
          soul.raw = soul.device.createBuffer({
            size: physicalSizeOf(soul.dataType),
            usage: soul.flags,
            mappedAtCreation: !!this.initial || !!this.#initialCallback,
            label: getName(this) ?? '<unnamed>',
          });

          if (this.initial || this.#initialCallback) {
            if (this.#initialCallback) {
              this.#initialCallback(this);
            } else if (this.initial) {
              writeToArrayBuffer(this.#getMappedRange(), this.dataType, this.initial);
            }
            this.#unmapBuffer();
          }
        }

        return soul.raw;
      },
    };
  }

  get dataType(): TData {
    return this[$soul].dataType;
  }

  get flags(): GPUBufferUsageFlags {
    return this[$soul].flags;
  }

  set flags(value: GPUBufferUsageFlags) {
    this[$soul].flags = value;
  }

  get buffer() {
    return this[$internal].materialize();
  }

  get destroyed() {
    return this.#destroyed;
  }

  get arrayBuffer(): ArrayBuffer {
    const gpuBuffer = this.buffer;
    if (gpuBuffer.mapState === 'mapped') {
      return this.#getMappedRange();
    }

    return this.#hostBuffer;
  }

  #getMappedRange(): ArrayBuffer {
    const raw = this[$soul].raw;
    if (!raw || raw.mapState !== 'mapped') {
      throw new Error('Buffer is not mapped.');
    }

    this.#mappedRange ??= raw.getMappedRange();
    return this.#mappedRange;
  }

  #unmapBuffer(): void {
    const raw = this[$soul].raw;
    if (!raw || raw.mapState !== 'mapped') {
      return;
    }

    this.#mappedRange = undefined;
    raw.unmap();
  }

  $name(label: string) {
    setName(this, label);
    const raw = this[$soul].raw;
    if (raw) {
      raw.label = label;
    }
    return this;
  }

  $usage<T extends UsageLiteral[]>(
    ...usages: T
  ): this & UnionToIntersection<LiteralToUsageType<T[number]>> {
    for (const usage of usages) {
      if (this.#disallowedUsages?.includes(usage)) {
        throw new Error(`Buffer of type ${this.dataType.type} cannot be used as ${usage}`);
      }

      if (usage === 'uniform') {
        warnIfNotUniformAligned(this.dataType);
      }

      this.flags |= usage === 'uniform' ? GPUBufferUsage.UNIFORM : 0;
      this.flags |= usage === 'storage' ? GPUBufferUsage.STORAGE : 0;
      this.flags |= usage === 'vertex' ? GPUBufferUsage.VERTEX : 0;
      this.flags |= usage === 'index' ? GPUBufferUsage.INDEX : 0;
      this.flags |= usage === 'indirect' ? GPUBufferUsage.INDIRECT : 0;
      this.usableAsUniform = this.usableAsUniform || usage === 'uniform';
      this.usableAsStorage = this.usableAsStorage || usage === 'storage';
      this.usableAsVertex = this.usableAsVertex || usage === 'vertex';
      this.usableAsIndex = this.usableAsIndex || usage === 'index';
      this.usableAsIndirect = this.usableAsIndirect || usage === 'indirect';
      if (!this[$soul].usages.includes(usage)) {
        this[$soul].usages.push(usage);
      }
    }
    return this as this & UnionToIntersection<LiteralToUsageType<T[number]>>;
  }

  $addFlags(flags: GPUBufferUsageFlags) {
    if (!this.#ownBuffer) {
      throw new Error('Cannot add flags to a buffer that is not managed by TypeGPU.');
    }

    if (flags & GPUBufferUsage.MAP_READ) {
      this.flags = GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ;
      return this;
    }

    if (flags & GPUBufferUsage.MAP_WRITE) {
      this.flags = GPUBufferUsage.COPY_SRC | GPUBufferUsage.MAP_WRITE;
      return this;
    }

    this.flags |= flags;
    return this;
  }

  compileWriter(): void {
    getCompiledWriter(this.dataType);
  }

  write(data: InferInput<TData>, options?: BufferWriteOptions): void;
  write(data: ArrayBuffer, options?: BufferWriteOptions): void;
  write(data: InferInput<TData> | ArrayBuffer, options?: BufferWriteOptions): void {
    const gpuBuffer = this.buffer;

    if (gpuBuffer.mapState === 'mapped') {
      const mapped = this.#getMappedRange();
      if (data instanceof ArrayBuffer && data === mapped) {
        // The caller already wrote data directly into the mapped range
        // via arrayBuffer. Nothing to do here
        return;
      }
      writeToArrayBuffer(mapped, this.dataType, data, options);
      return;
    }

    const { startOffset, endOffset } = calculateOffsets(options, this.dataType, data);
    const size = this.#alignedWriteSize(startOffset, endOffset);

    // If the caller already wrote directly into #hostBuffer via
    // arrayBuffer, skip the redundant copy, the data is already in place.
    if (!(data instanceof ArrayBuffer && data === this.#hostBuffer)) {
      writeToArrayBuffer(this.#hostBuffer, this.dataType, data, options);
    }

    this[$soul].device.queue.writeBuffer(
      gpuBuffer,
      startOffset,
      this.#hostBuffer,
      startOffset,
      size,
    );
  }

  /**
   * Returns the number of bytes to upload when writing to `[startOffset, endOffset)`.
   * Writes that reach the end of the schema also cover the trailing padding (see {@link physicalSizeOf}).
   * Other writes have to be 4-byte aligned already, since filling in the neighboring bytes
   * from the host could overwrite data that was changed on the GPU.
   */
  #alignedWriteSize(startOffset: number, endOffset: number): number {
    const paddedEndOffset =
      endOffset === sizeOf(this.dataType) ? physicalSizeOf(this.dataType) : endOffset;
    const size = paddedEndOffset - startOffset;

    if (startOffset % 4 !== 0 || size % 4 !== 0) {
      throw new Error(
        `Cannot write to bytes ${startOffset}-${endOffset} of buffer '${getName(this) ?? '<unnamed>'}'. ` +
          'WebGPU requires writes to start and end at a multiple of 4 bytes. ' +
          'Align the range to 4 bytes, write the whole buffer, or use 4-byte elements (e.g. d.u32 instead of d.u16).',
      );
    }

    return size;
  }

  /** @deprecated Use {@link patch} instead. */
  public writePartial(data: InferPartial<TData>): void {
    this.patch(convertPartialToPatch(this.dataType, data) as InferPatch<TData>);
  }

  public patch(data: InferPatch<TData>): void {
    const gpuBuffer = this.buffer;

    if (gpuBuffer.mapState === 'mapped') {
      patchArrayBuffer(this.#getMappedRange(), this.dataType, data);
    } else {
      // Every range is validated before the patch touches #hostBuffer, so a failing patch
      // is neither uploaded halfway nor left behind in `arrayBuffer`
      const instructions = getPatchInstructions(
        this.dataType,
        data,
        this.#hostBuffer,
        (start, end) => this.#alignedWriteSize(start, end),
      );
      for (const { data, gpuOffset, uploadSize } of instructions) {
        if (uploadSize === data.byteLength) {
          this[$soul].device.queue.writeBuffer(gpuBuffer, gpuOffset, data);
        } else {
          // Extending the write into the trailing padding (see physicalSizeOf)
          const padded = new Uint8Array(uploadSize);
          padded.set(data);
          this[$soul].device.queue.writeBuffer(gpuBuffer, gpuOffset, padded);
        }
      }
    }
  }

  public clear(encoder?: TgpuCommandEncoder): void {
    const gpuBuffer = this.buffer;

    if (encoder) {
      encoder[$internal].rawEncoder.clearBuffer(gpuBuffer);
      return;
    }

    if (gpuBuffer.mapState === 'mapped') {
      new Uint8Array(this.#getMappedRange()).fill(0);
      return;
    }

    const rawEncoder = this[$soul].device.createCommandEncoder();
    rawEncoder.clearBuffer(gpuBuffer);
    this[$soul].device.queue.submit([rawEncoder.finish()]);
  }

  copyFrom(srcBuffer: TgpuBuffer<MemIdentity<TData>>, encoder?: TgpuCommandEncoder): void {
    if (this.buffer.mapState === 'mapped') {
      throw new Error('Cannot copy to a mapped buffer.');
    }

    const size = physicalSizeOf(this.dataType);

    if (encoder) {
      encoder[$internal].rawEncoder.copyBufferToBuffer(srcBuffer.buffer, 0, this.buffer, 0, size);
      return;
    }

    const rawEncoder = this[$soul].device.createCommandEncoder();
    rawEncoder.copyBufferToBuffer(srcBuffer.buffer, 0, this.buffer, 0, size);
    this[$soul].device.queue.submit([rawEncoder.finish()]);
  }

  async read(): Promise<Infer<TData>> {
    const gpuBuffer = this.buffer;

    if (gpuBuffer.mapState === 'mapped') {
      return readFromArrayBuffer(this.#getMappedRange(), this.dataType);
    }

    if (gpuBuffer.usage & GPUBufferUsage.MAP_READ) {
      await gpuBuffer.mapAsync(GPUMapMode.READ);
      const res = readFromArrayBuffer(this.#getMappedRange(), this.dataType);
      this.#unmapBuffer();
      return res;
    }

    const size = physicalSizeOf(this.dataType);
    const stagingBuffer = this[$soul].device.createBuffer({
      size,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    });

    const commandEncoder = this[$soul].device.createCommandEncoder();
    commandEncoder.copyBufferToBuffer(gpuBuffer, 0, stagingBuffer, 0, size);

    this[$soul].device.queue.submit([commandEncoder.finish()]);
    await stagingBuffer.mapAsync(GPUMapMode.READ, 0, size);

    const res = readFromArrayBuffer(stagingBuffer.getMappedRange(), this.dataType);

    stagingBuffer.unmap();
    stagingBuffer.destroy();

    return res;
  }

  as<T extends ViewUsages<this>>(usage: T): UsageTypeToBufferBinding<TData>[T] {
    return usageToUsageConstructor[usage](this as never) as UsageTypeToBufferBinding<TData>[T];
  }

  destroy() {
    if (this.#destroyed) {
      return;
    }
    this.#destroyed = true;
    this.#mappedRange = undefined;
    if (this.#ownBuffer) {
      this[$soul].raw?.destroy();
    }
  }

  toString(): string {
    return `buffer:${getName(this) ?? '<unnamed>'}`;
  }
}
