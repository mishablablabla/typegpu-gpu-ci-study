import { UnknownData } from '../data/dataTypes.ts';
import { abstractFloat, abstractInt, bool, f32, i32 } from '../data/numeric.ts';
import { isRef } from '../data/ref.ts';
import { isStoredInMemory, isSnippet, snip, withDataType } from '../data/snippet.ts';
import type { ResolvedSnippet, Snippet } from '../data/snippet.ts';
import {
  type AnyWgslData,
  type BaseData,
  type F32,
  type I32,
  isMatInstance,
  isNaturallyEphemeral,
  isVecInstance,
  type WgslArray,
  WORKAROUND_getSchema,
} from '../data/wgslTypes.ts';
import {
  asComptime,
  type ComptimeValue,
  getOwnSnippet,
  type ResolutionCtx,
  type SelfResolvable,
  type WithComptimeValue,
} from '../types.ts';
import { WgslTypeError } from '../errors.ts';
import { $comptimeValueOf, $internal, $resolve } from '../shared/symbols.ts';
import { logger } from '../tgpuLogger.ts';
import { stringifySnippet } from './stringifySnippet.ts';

export function numericLiteralToSnippet(value: number): Snippet {
  if (value >= 2 ** 63 || value < -(2 ** 63)) {
    return snip(value, abstractFloat, /* origin */ 'constant', /* possibleSideEffects */ false);
  }
  // WGSL AbstractInt uses 64-bit precision, but JS numbers are only safe up to 2^53 - 1.
  // Warn when values exceed this range to prevent precision loss.
  if (Number.isInteger(value)) {
    if (!Number.isSafeInteger(value)) {
      logger.warn(
        'precision-loss',
        `The integer ${value} exceeds the safe integer range and may have lost precision.`,
      );
    }
    return snip(value, abstractInt, /* origin */ 'constant', /* possibleSideEffects */ false);
  }
  return snip(value, abstractFloat, /* origin */ 'constant', /* possibleSideEffects */ false);
}

export function concretize<T extends BaseData>(type: T): T | F32 | I32 {
  if (type.type === 'abstractFloat') {
    return f32;
  }

  if (type.type === 'abstractInt') {
    return i32;
  }

  return type;
}

export function concretizeSnippet(snippet: Snippet): Snippet {
  return withDataType(concretize(snippet.dataType as AnyWgslData), snippet);
}

export function concretizeSnippets(args: Snippet[]): Snippet[] {
  return args.map(concretizeSnippet);
}

export function coerceToSnippet(value: unknown): Snippet {
  if (isSnippet(value)) {
    // Already a snippet
    return value;
  }

  if (isRef(value)) {
    throw new Error('Cannot use refs (d.ref(...)) from the outer scope.');
  }

  // Maybe the value can tell us what snippet it is
  const ownSnippet = getOwnSnippet(value);
  if (ownSnippet) {
    return ownSnippet;
  }

  if (isVecInstance(value) || isMatInstance(value)) {
    return snip(
      value,
      WORKAROUND_getSchema(value),
      /* origin */ 'constant',
      /* possibleSideEffects */ false,
    );
  }

  if (typeof value === 'number') {
    return numericLiteralToSnippet(value);
  }

  if (typeof value === 'boolean') {
    return snip(value, bool, /* origin */ 'constant', /* possibleSideEffects */ false);
  }

  return snip(value, UnknownData, /* origin */ 'constant', /* possibleSideEffects */ false);
}

/**
 * Intermediate representation for WGSL array expressions.
 * Defers resolution. Stores array elements as snippets so the
 * generator can access them when needed.
 */
export class ArrayExpression implements SelfResolvable, WithComptimeValue {
  readonly [$internal] = true;
  readonly type: WgslArray<AnyWgslData>;
  readonly elements: Snippet[];

  constructor(type: WgslArray<AnyWgslData>, elements: Snippet[]) {
    this.type = type;
    this.elements = elements;
  }

  toString(): string {
    return 'ArrayExpression';
  }

  [$comptimeValueOf](): ComptimeValue {
    // The array is known at comptime only if every element is known at comptime
    const values: unknown[] = [];
    for (const elem of this.elements) {
      const known = asComptime(elem);
      if (!known) {
        return { comptime: false };
      }
      values.push(known.value);
    }
    return { comptime: true, value: values };
  }

  [$resolve](ctx: ResolutionCtx): ResolvedSnippet {
    for (const elem of this.elements) {
      // We check if there are no references among the elements
      if (isStoredInMemory(elem) && !isNaturallyEphemeral(elem.dataType)) {
        const snippetStr = stringifySnippet(elem);
        const snippetType = ctx.resolve(concretize(elem.dataType as BaseData)).value;
        throw new WgslTypeError(
          `'${snippetStr}' reference cannot be used in an array constructor.\n-----\nTry '${snippetType}(${snippetStr})' or 'arrayOf(${snippetType}, count)([...])' to copy the value instead.\n-----`,
        );
      }
    }

    return ctx.gen.typeInstantiation(this.type, this.elements);
  }
}
