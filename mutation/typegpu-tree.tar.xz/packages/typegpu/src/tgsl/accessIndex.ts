import { stitch } from '../core/resolve/stitch.ts';
import { isDisarray } from '../data/dataTypes.ts';
import { MatrixColumnsAccess } from '../data/matrixColumnsAccess.ts';
import { derefSnippet } from '../data/ref.ts';
import { snip } from '../data/snippet.ts';
import type { Origin, Snippet } from '../data/snippet.ts';
import { vec2f, vec3f, vec4f } from '../data/vector.ts';
import { type BaseData, isPtr, isVec, isWgslArray } from '../data/wgslTypes.ts';
import { asComptime } from '../types.ts';
import { accessProp } from './accessProp.ts';
import { ArrayExpression, coerceToSnippet } from './generationHelpers.ts';

const indexableTypeToResult = {
  mat2x2f: vec2f,
  mat3x3f: vec3f,
  mat4x4f: vec4f,
} as const;

function deriveIndexAccessOrigin(targetOrigin: Origin, indexOrigin: Origin): Origin {
  if (targetOrigin === 'constant-immutable-def') {
    // Constant refs stay const unless the index forces runtime materialization
    return indexOrigin === 'constant' || indexOrigin === 'constant-immutable-def'
      ? 'constant-immutable-def'
      : 'runtime-immutable-def';
  }
  if (targetOrigin === 'constant') {
    // Ephemeral constants indexed with constants stay constant, otherwise they become runtime-known
    return indexOrigin === 'constant' || indexOrigin === 'constant-immutable-def'
      ? 'constant'
      : 'runtime';
  }
  // Fallthrough
  return targetOrigin;
}

export function accessIndex(target: Snippet, indexArg: Snippet | number): Snippet | undefined {
  const index = typeof indexArg === 'number' ? coerceToSnippet(indexArg) : indexArg;
  const knownIndex = asComptime(index);

  // array
  if (isWgslArray(target.dataType) || isDisarray(target.dataType)) {
    const elementType = target.dataType.elementType;

    if (target.value instanceof ArrayExpression && knownIndex) {
      return target.value.elements[knownIndex.value as number];
    }

    const origin = deriveIndexAccessOrigin(target.origin, index.origin);
    const knownTarget = knownIndex && asComptime(target);
    return snip(
      knownTarget && knownIndex
        ? // oxlint-disable-next-line typescript/no-explicit-any -- it's fine, it's there
          (knownTarget.value as any)[knownIndex.value as number]
        : stitch`${target}[${index}]`,
      elementType,
      /* origin */ origin,
      target.possibleSideEffects || index.possibleSideEffects,
    );
  }

  // vector
  if (isVec(target.dataType)) {
    const knownTarget = knownIndex && asComptime(target);
    return snip(
      knownTarget && knownIndex
        ? // oxlint-disable-next-line typescript/no-explicit-any -- it's fine, it's there
          (knownTarget.value as any)[knownIndex.value as any]
        : stitch`${target}[${index}]`,
      target.dataType.primitive,
      deriveIndexAccessOrigin(target.origin, index.origin),
      target.possibleSideEffects || index.possibleSideEffects,
    );
  }

  if (isPtr(target.dataType)) {
    // Sometimes values that are typed as pointers aren't instances of `d.ref`, so we
    // allow indexing as if it wasn't a pointer.
    return accessIndex(derefSnippet(target), index);
  }

  // matrix.columns
  if (target.value instanceof MatrixColumnsAccess) {
    const propType =
      indexableTypeToResult[
        (target.value.matrix.dataType as BaseData).type as keyof typeof indexableTypeToResult
      ];

    return snip(
      stitch`${target.value.matrix}[${index}]`,
      propType,
      deriveIndexAccessOrigin(target.origin, index.origin),
      target.possibleSideEffects || index.possibleSideEffects,
    );
  }

  // matrix
  if ((target.dataType as BaseData).type in indexableTypeToResult) {
    throw new Error(
      "The only way of accessing matrix elements in TypeGPU functions is through the 'columns' property.",
    );
  }

  const knownTarget = knownIndex && asComptime(target);
  if (knownTarget && knownIndex) {
    // No idea what the type is, so we act on the snippet's value and try to guess
    return coerceToSnippet(
      // oxlint-disable-next-line typescript/no-explicit-any -- we're inspecting the value, and it could be any value
      (knownTarget.value as any)[knownIndex.value as number],
    );
  }

  if (typeof knownIndex?.value === 'string') {
    return accessProp(target, knownIndex.value);
  }

  return undefined;
}
