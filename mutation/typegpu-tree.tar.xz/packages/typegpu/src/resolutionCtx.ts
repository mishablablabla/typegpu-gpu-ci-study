import type { TgpuImmediateVar } from './core/immediate/immediateVar.ts';
import type { Namespace, NamespaceInternal } from './core/resolve/namespace.ts';
import { ConfigurableImpl } from './core/root/configurableImpl.ts';
import type { Configurable, ExperimentalTgpuRoot } from './core/root/rootTypes.ts';
import {
  type Eventual,
  isLazy,
  isProviding,
  isSlot,
  type SlotValuePair,
  type TgpuLazy,
  type TgpuSlot,
} from './core/slot/slotTypes.ts';
import { isData, UnknownData } from './data/dataTypes.ts';
import { bool } from './data/numeric.ts';
import {
  type Origin,
  type ResolvedSnippet,
  snip,
  type Snippet,
  withValue,
} from './data/snippet.ts';
import { type BaseData, isPtr, isWgslArray, isWgslStruct, Void } from './data/wgslTypes.ts';
import { invariant, MissingSlotValueError, ResolutionError, WgslTypeError } from './errors.ts';
import { provideCtx, topLevelState } from './execMode.ts';
import { naturalsExcept } from './shared/generators.ts';
import { isMarkedInternal } from './shared/symbols.ts';
import type { Infer } from './shared/repr.ts';
import { safeStringify } from './shared/stringify.ts';
import { $internal, $providing, $resolve } from './shared/symbols.ts';
import {
  bindGroupLayout,
  type TgpuBindGroup,
  TgpuBindGroupImpl,
  type TgpuBindGroupLayout,
  type TgpuLayoutEntry,
} from './tgpuBindGroupLayout.ts';
import { LogGeneratorImpl, LogGeneratorNullImpl } from './tgsl/consoleLog/logGenerator.ts';
import type { LogGenerator, LogResources, SupportedLogOp } from './tgsl/consoleLog/types.ts';
import { getBestConversion } from './tgsl/conversion.ts';
import { coerceToSnippet, concretize, numericLiteralToSnippet } from './tgsl/generationHelpers.ts';
import type { ShaderGenerator } from './tgsl/shaderGenerator.ts';
import { WgslGenerator } from './tgsl/wgslGenerator.ts';
import type {
  BlockScopeLayer,
  ExecMode,
  ExecState,
  ResolveFunctionOptions,
  FunctionArgumentAccess,
  FunctionScopeLayer,
  ItemLayer,
  ItemStateStack,
  ResolutionCtx,
  StackLayer,
  ShaderStage,
  Wgsl,
} from './types.ts';
import { CodegenState, isSelfResolvable, NormalState, type FunctionArgument } from './types.ts';
import type { WgslEnableExtension } from './wgslExtensions.ts';
import { getName, hasTinyestMetadata, isNamable, setName } from './shared/meta.ts';
import { FuncParameterType } from 'tinyest';
import { accessProp } from './tgsl/accessProp.ts';
import { createIoSchema } from './core/function/ioSchema.ts';
import { isShelllessImpl } from './core/function/shelllessImpl.ts';
import { isTgpuFn } from './core/function/tgpuFn.ts';
import type { IOData } from './core/function/fnTypes.ts';
import { AutoStruct } from './data/autoStruct.ts';
import { EntryInputRouter } from './core/function/entryInputRouter.ts';
import { validateIdentifier, sanitizePrimer, bannedTokens } from './nameUtils.ts';
import { minify } from './minify.ts';

/**
 * Inserted into bind group entry definitions that belong
 * to the automatically generated catch-all bind group.
 *
 * A non-occupied group index can only be determined after
 * every resource has been resolved, so this acts as a placeholder
 * to be replaced with an actual numeric index at the very end
 * of the resolution process.
 */
const CATCHALL_BIND_GROUP_IDX_MARKER = '#CATCHALL#';

export type ResolutionCtxImplOptions = {
  readonly enableExtensions?: WgslEnableExtension[] | undefined;
  readonly shaderGenerator?: ShaderGenerator | undefined;
  readonly config?: ((cfg: Configurable) => Configurable) | undefined;
  readonly root?: ExperimentalTgpuRoot | undefined;
  readonly namespace: Namespace;
  readonly minify: boolean;
};

class ItemStateStackImpl implements ItemStateStack {
  private _stack: StackLayer[] = [];
  private _itemDepth = 0;

  get itemDepth(): number {
    return this._itemDepth;
  }

  get topItem(): ItemLayer {
    const state = this._stack[this._stack.length - 1];
    if (!state || state.type !== 'item') {
      throw new Error('Internal error, expected item layer to be on top.');
    }
    return state;
  }

  get topFunctionScope(): FunctionScopeLayer | undefined {
    return this._stack.findLast((e) => e.type === 'functionScope');
  }

  get topBlockScope(): BlockScopeLayer | undefined {
    return this._stack.findLast((e) => e.type === 'blockScope');
  }

  get blockDepth(): number {
    let depth = 0;
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];
      if (layer?.type === 'functionScope') {
        break;
      }
      if (layer?.type === 'blockScope') {
        depth++;
      }
    }

    return depth;
  }

  pushItem() {
    this._itemDepth++;
    this._stack.push({
      type: 'item',
      usedSlots: new Set(),
    });
  }

  pushSlotBindings(pairs: SlotValuePair[]) {
    this._stack.push({
      type: 'slotBinding',
      bindingMap: new WeakMap(pairs),
    });
  }

  pushFunctionScope(
    functionType: 'normal' | ShaderStage,
    argAccess: Record<string, FunctionArgumentAccess>,
    returnType: BaseData | undefined,
    externalMap: Record<string, unknown>,
  ): FunctionScopeLayer {
    const scope: FunctionScopeLayer = {
      type: 'functionScope',
      functionType,
      argAccess,
      returnType,
      externalMap,
      reportedReturnTypes: new Set(),
      placeholderForVariable: new Map(),
      modifiedVariables: new Set(),
    };

    this._stack.push(scope);
    return scope;
  }

  pushBlockScope() {
    this._stack.push({
      type: 'blockScope',
      takenLocalIdentifiers: new Set(),
      declarations: new Map(),
      externals: new Map(),
    });
  }

  pop<T extends StackLayer['type']>(type: T): Extract<StackLayer, { type: T }>;
  pop(): StackLayer | undefined;
  pop(type?: StackLayer['type']) {
    const layer = this._stack[this._stack.length - 1];
    if (!layer || (type && layer.type !== type)) {
      throw new Error(`Internal error, expected a ${type} layer to be on top.`);
    }

    const poppedValue = this._stack.pop();
    if (type === 'item') {
      this._itemDepth--;
    }
    return poppedValue;
  }

  readSlot<T>(slot: TgpuSlot<T>): T | undefined {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];
      if (layer?.type === 'item') {
        // Binding not available yet, so this layer is dependent on the slot's value.
        layer.usedSlots.add(slot);
      } else if (layer?.type === 'slotBinding') {
        const boundValue = layer.bindingMap.get(slot);

        if (boundValue !== undefined) {
          return boundValue as T;
        }
      } else if (layer?.type === 'functionScope' || layer?.type === 'blockScope') {
        // Skip
      } else {
        throw new Error('Unknown layer type.');
      }
    }

    return slot.defaultValue;
  }

  getSnippetById(id: string): Snippet | undefined {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];

      if (layer?.type === 'functionScope') {
        const access = layer.argAccess[id];
        if (access) {
          return access();
        }

        if (Object.hasOwn(layer.externalMap, id)) {
          const external = layer.externalMap[id];
          if (isNamable(external) && getName(external) === undefined) {
            setName(external, id.replaceAll('.', '_'));
          }
          return coerceToSnippet(external);
        }

        return undefined;
      }

      if (layer?.type === 'blockScope') {
        // the order matters
        const snippet = layer.declarations.get(id) ?? layer.externals.get(id);
        if (snippet !== undefined) {
          return snippet;
        }
      } else {
        // Skip
      }
    }

    return undefined;
  }

  /**
   * Returns whether the given identifier is taken in any block scope up to the nearest function scope.
   */
  isIdentifierTakenLocally(id: string): boolean {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];

      if (layer?.type === 'functionScope') {
        // Since functions cannot access resources from the calling scope, we
        // return early here.
        return false;
      }

      if (layer?.type === 'blockScope') {
        if (layer.takenLocalIdentifiers.has(id)) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Returns whether the given identifier is taken in any block scope on the stack.
   *
   * This is useful when resolving a global identifier for the first time within a nested function.
   */
  isIdentifierTakenInCallStack(id: string): boolean {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];
      if (layer?.type === 'blockScope') {
        if (layer.takenLocalIdentifiers.has(id)) {
          return true;
        }
      }
    }

    return false;
  }

  defineBlockVariable(id: string, snippet: Snippet): void {
    if (snippet.dataType === UnknownData) {
      throw Error(`Tried to define variable '${id}' of unknown type`);
    }

    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];

      if (layer?.type === 'blockScope') {
        layer.declarations.set(id, snippet);
        return;
      }
    }

    throw new Error('No block scope found to define a variable in.');
  }

  setBlockExternals(externals: Record<string, Snippet>) {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];
      if (layer?.type === 'blockScope') {
        Object.entries(externals).forEach(([id, snippet]) => {
          layer.externals.set(id, snippet);
        });
        return;
      }
    }
    throw new Error('No block scope found to set externals in.');
  }

  clearBlockExternals() {
    for (let i = this._stack.length - 1; i >= 0; --i) {
      const layer = this._stack[i];
      if (layer?.type === 'blockScope') {
        layer.externals.clear();
        return;
      }
    }
    throw new Error('No block scope found to clear externals in.');
  }
}

const INDENT = [
  '', // 0
  '  ', // 1
  '    ', // 2
  '      ', // 3
  '        ', // 4
  '          ', // 5
  '            ', // 6
  '              ', // 7
  '                ', // 8
];

const N = INDENT.length - 1;

export class IndentController {
  identLevel = 0;

  get pre(): string {
    return (
      INDENT[this.identLevel] ??
      (INDENT[N] as string).repeat(this.identLevel / N) + INDENT[this.identLevel % N]
    );
  }

  indent(): string {
    const str = this.pre;
    this.identLevel++;
    return str;
  }

  dedent(): string {
    this.identLevel--;
    return this.pre;
  }

  withResetLevel<T>(callback: () => T): T {
    const savedLevel = this.identLevel;
    this.identLevel = 0;
    try {
      return callback();
    } finally {
      this.identLevel = savedLevel;
    }
  }
}

interface FixedBindingConfig {
  layoutEntry: TgpuLayoutEntry;
  resource: object;
}

function createArgument(
  name: string,
  type: BaseData,
  origin: Origin = 'argument',
): FunctionArgument {
  let used = false;

  return {
    name,
    access: () => {
      used = true;
      return snip(name, type, origin, /* possibleSideEffects */ false);
    },
    decoratedType: type,
    get used() {
      return used;
    },
  };
}

function createArgumentPropAccess(
  argAccess: FunctionArgumentAccess,
  prop: string,
): FunctionArgumentAccess {
  return () => {
    const argSnippet = argAccess();
    if (!argSnippet) {
      return undefined;
    }
    return accessProp(argSnippet, prop);
  };
}

export class ResolutionCtxImpl implements ResolutionCtx {
  readonly #namespaceInternal: NamespaceInternal;

  private readonly _indentController = new IndentController();
  private readonly _itemStateStack = new ItemStateStackImpl();
  readonly #modeStack: ExecState[] = [];
  private readonly _declarations: ResolvedDeclaration[] = [];
  private _varyingLocations: Record<string, number> | undefined;
  /**
   * Holds a set of base (slot-less) functions that have started their resolution process.
   * Used for recursion detection check - a function is recursive if:
   * - it was passed to ctx.resolve while already present in this set,
   * - it never finished resolution (<=> it does not appear in `memoizedResolves`).
   * The set is NOT cleared after the resolution finishes.
   */
  readonly #startedFunctionResolves: WeakSet<object> = new WeakSet();
  readonly #logGenerator: LogGenerator;

  readonly gen: ShaderGenerator;

  get varyingLocations() {
    return this._varyingLocations;
  }

  readonly [$internal] = {
    itemStateStack: this._itemStateStack,
  };

  // -- Bindings
  /**
   * A map from registered bind group layouts to random strings put in
   * place of their group index. The whole tree has to be traversed to
   * collect every use of a typed bind group layout, since they can be
   * explicitly imposed group indices, and they cannot collide.
   */
  public readonly bindGroupLayoutsToPlaceholderMap = new Map<TgpuBindGroupLayout, string>();
  private _nextFreeLayoutPlaceholderIdx = 0;
  public readonly fixedBindings: FixedBindingConfig[] = [];
  // --

  public readonly enableExtensions: WgslEnableExtension[] | undefined;
  public expectedType: BaseData | undefined;

  #usedImmediate: TgpuImmediateVar | undefined;

  /**
   * A counter used to generate unique identifiers for globally-scoped definitions in the 'random' strategy.
   */
  #lastUniqueId = 0;

  constructor(opts: ResolutionCtxImplOptions) {
    this.enableExtensions = opts.enableExtensions;
    this.#logGenerator = opts.root ? new LogGeneratorImpl(opts.root) : new LogGeneratorNullImpl();
    this.#namespaceInternal = opts.namespace[$internal];
    this.gen = opts.shaderGenerator ?? new WgslGenerator();
    this.gen.initGenerator(this);
  }

  registerImmediate(immediate: TgpuImmediateVar): void {
    if (this.#usedImmediate !== undefined && this.#usedImmediate !== immediate) {
      throw new Error(
        `Cannot use both immediate variables '${getName(this.#usedImmediate) ?? '<unnamed>'}' and '${
          getName(immediate) ?? '<unnamed>'
        }' in a single shader. At most one immediate variable is allowed per resolution.`,
      );
    }
    this.#usedImmediate = immediate;
  }

  get usedImmediate(): TgpuImmediateVar | undefined {
    return this.#usedImmediate;
  }

  isIdentifierBanned(name: string): boolean {
    return bannedTokens.has(name);
  }

  isIdentifierTaken(name: string, scope: 'global' | 'block'): boolean {
    return (
      this.#namespaceInternal.takenGlobalIdentifiers.has(name) ||
      (scope === 'block'
        ? this._itemStateStack.isIdentifierTakenLocally(name)
        : this._itemStateStack.isIdentifierTakenInCallStack(name))
    );
  }

  makeUniqueIdentifier(primer: string = 'item', scope: 'global' | 'block'): string {
    if (
      scope === 'block' &&
      validateIdentifier(primer).success &&
      !this.isIdentifierTaken(primer, scope)
    ) {
      // Preserving local definitions as they are, provided they are valid and not already taken.
      this.reserveIdentifier(primer, 'block');
      return primer;
    }

    const base = sanitizePrimer(primer);
    let index = 0;
    const random = this.#namespaceInternal.strategy === 'random';
    let name = random ? `${base}_${this.#lastUniqueId++}` : base;
    while (this.isIdentifierTaken(name, scope)) {
      name = random ? `${base}_${this.#lastUniqueId++}` : `${base}_${++index}`;
    }

    this.reserveIdentifier(name, scope);
    return name;
  }

  reserveIdentifier(name: string, scope: 'global' | 'block'): void {
    if (scope === 'block') {
      const blockScope = this._itemStateStack.topBlockScope;
      if (blockScope) {
        blockScope.takenLocalIdentifiers.add(name);
        return;
      }
      // Fall through if no block scope is present, treating as global.
    }
    this.#namespaceInternal.takenGlobalIdentifiers.add(name);
  }

  get pre(): string {
    return this._indentController.pre;
  }

  get topFunctionScope() {
    return this._itemStateStack.topFunctionScope;
  }

  get topFunctionReturnType() {
    const scope = this._itemStateStack.topFunctionScope;
    invariant(scope, 'Internal error, expected function scope to be present.');
    return scope.returnType;
  }

  get shelllessRepo() {
    return this.#namespaceInternal.shelllessRepo;
  }

  get blockDepth(): number {
    return this._itemStateStack.blockDepth;
  }

  indent(): string {
    return this._indentController.indent();
  }

  dedent(): string {
    return this._indentController.dedent();
  }

  getDedented(code: string): string {
    return code.replaceAll(`\n${INDENT[1]}`, '\n').replaceAll(new RegExp(`^${INDENT[1]}`, 'g'), '');
  }

  withResetIndentLevel<T>(callback: () => T): T {
    return this._indentController.withResetLevel(callback);
  }

  getById(id: string): Snippet | null {
    const item = this._itemStateStack.getSnippetById(id);

    if (item === undefined) {
      return null;
    }

    return item;
  }

  defineVariable(id: string, snippet: Snippet) {
    this._itemStateStack.defineBlockVariable(id, snippet);
  }

  reportReturnType(dataType: BaseData) {
    const scope = this._itemStateStack.topFunctionScope;
    invariant(scope, 'Internal error, expected function scope to be present.');
    scope.reportedReturnTypes.add(dataType);
  }

  pushBlockScope() {
    this._itemStateStack.pushBlockScope();
  }

  popBlockScope() {
    this._itemStateStack.pop('blockScope');
  }

  setBlockExternals(externals: Record<string, Snippet>) {
    this._itemStateStack.setBlockExternals(externals);
  }

  clearBlockExternals() {
    this._itemStateStack.clearBlockExternals();
  }

  generateLog(op: SupportedLogOp, args: Snippet[]): Snippet {
    return this.#logGenerator.generateLog(this, op, args);
  }

  get logResources(): LogResources | undefined {
    return this.#logGenerator.logResources;
  }

  resolveFunction(options: ResolveFunctionOptions): { code: string; returnType: BaseData } {
    try {
      const scope = this._itemStateStack.pushFunctionScope(
        options.functionType,
        {},
        options.returnType,
        options.externalMap,
      );
      // Pushing a block scope as well, so that any identifiers declared at this point will be scoped to the function body.
      this._itemStateStack.pushBlockScope();

      const args: FunctionArgument[] = [];

      if (options.entryInput) {
        const { dataSchema, positionalArgs } = options.entryInput;
        const firstParam = options.params[0];

        const structArg = dataSchema
          ? createArgument(this.makeUniqueIdentifier('_arg_0', 'block'), dataSchema)
          : undefined;

        if (structArg) {
          args.push(structArg);
        }

        if (firstParam?.type === FuncParameterType.destructuredObject) {
          // Route each destructured prop to a positional arg or struct field.
          for (const { name, alias } of firstParam.props) {
            const argInfo = positionalArgs.find((a) => a.schemaKey === name);
            if (argInfo) {
              const arg = createArgument(this.makeUniqueIdentifier(alias, 'block'), argInfo.type);
              args.push(arg);
              scope.argAccess[alias] = arg.access;
            } else if (structArg) {
              scope.argAccess[alias] = createArgumentPropAccess(structArg.access, name);
            }
          }
        } else if (firstParam?.type === FuncParameterType.identifier) {
          // Create named arg snippets, then a proxy for property access routing.
          const proxyEntries: Array<{ schemaKey: string; arg: FunctionArgumentAccess }> = [];
          for (const a of positionalArgs) {
            const argName = this.makeUniqueIdentifier(a.schemaKey, 'block');
            const arg = createArgument(argName, a.type);
            args.push(arg);
            proxyEntries.push({ schemaKey: a.schemaKey, arg: arg.access });
          }
          const router = new EntryInputRouter(structArg?.access, proxyEntries);
          scope.argAccess[firstParam.name] = () => snip('N/A', router, 'argument');
        } else {
          // No first param: push positional args with schema key names.
          for (const a of positionalArgs) {
            const argName = this.makeUniqueIdentifier(`_arg_${a.schemaKey}`, 'block');
            const arg = createArgument(argName, a.type);
            args.push(arg);
            scope.argAccess[argName] = arg.access;
          }
        }
      } else {
        for (const [i, argType] of options.argTypes.entries()) {
          const astParam = options.params[i];
          // We know if arguments are passed by reference or by value, because we
          // enforce that based on the whether the argument is a pointer or not.
          //
          // It still applies for shell-less functions, since we determine the type
          // of the argument based on the argument's referentiality.
          // In other words, if we pass a reference to a function, it's typed as a pointer,
          // otherwise it's typed as a value.
          const origin = isPtr(argType)
            ? argType.addressSpace === 'storage'
              ? argType.access === 'read'
                ? 'readonly'
                : 'mutable'
              : argType.addressSpace
            : 'argument';

          switch (astParam?.type) {
            case FuncParameterType.identifier: {
              const arg = createArgument(
                this.makeUniqueIdentifier(astParam.name, 'block'),
                argType,
                origin,
              );
              args.push(arg);
              scope.argAccess[astParam.name] = arg.access;
              break;
            }
            case FuncParameterType.destructuredObject: {
              const objArg = createArgument(
                this.makeUniqueIdentifier(`_arg_${i}`, 'block'),
                argType,
                origin,
              );
              args.push(objArg);
              for (const { name, alias } of astParam.props) {
                scope.argAccess[alias] = createArgumentPropAccess(objArg.access, name);
              }
              break;
            }
            case undefined: {
              // Only push the argument if it's not an auto-struct.
              // If we're not using an auto-struct, it's not going to
              // have any properties anyway.
              if (!(argType instanceof AutoStruct)) {
                args.push({
                  name: this.makeUniqueIdentifier(`_arg_${i}`, 'block'),
                  access: () => {
                    throw new Error(
                      `Unreachable: Accessing an argument that wasn't named in the function signature`,
                    );
                  },
                  decoratedType: argType,
                  used: false,
                });
              }
            }
          }
        }
      }

      let returnType: BaseData | undefined;

      const code = this.gen.functionDefinition({
        functionType: options.functionType,
        name: options.name,
        workgroupSize: options.workgroupSize,
        args,
        body: options.body,
        determineReturnType: () => {
          if (returnType) {
            // Already determined
            return returnType;
          }

          returnType = options.returnType;
          if (returnType instanceof AutoStruct) {
            // We're expecting an "auto" return type, so if there were structs returned,
            // we accept the struct, otherwise we let the rest of the code unify on a
            // primitive type.
            if (isWgslStruct(scope.reportedReturnTypes.values().next().value)) {
              returnType = returnType.completeStruct;
            } else {
              returnType = undefined;
            }
          }

          if (!returnType) {
            const returnTypes = [...scope.reportedReturnTypes];
            if (returnTypes.length === 0) {
              returnType = Void;
            } else {
              const conversion = getBestConversion(returnTypes);
              if (conversion && !conversion.hasImplicitConversions) {
                returnType = conversion.targetType;
              }
            }

            if (!returnType) {
              throw new Error(
                `Expected function to have a single return type, got [${returnTypes.join(
                  ', ',
                )}]. Cast explicitly to the desired type.`,
              );
            }

            returnType = concretize(returnType);

            if (options.functionType === 'vertex' || options.functionType === 'fragment') {
              returnType = createIoSchema(returnType as IOData);
            }
          }
          return returnType;
        },
      });

      if (!returnType) {
        throw new Error(`Failed to determine return type`);
      }

      return {
        code,
        returnType,
      };
    } finally {
      this._itemStateStack.pop('blockScope');
      this._itemStateStack.pop('functionScope');
    }
  }

  addDeclaration(declaration: string, name?: string): void {
    this._declarations.push({ name, code: declaration });
  }

  get declarations(): readonly ResolvedDeclaration[] {
    return this._declarations;
  }

  allocateLayoutEntry(layout: TgpuBindGroupLayout): string {
    const memoMap = this.bindGroupLayoutsToPlaceholderMap;
    let placeholderKey = memoMap.get(layout);

    if (!placeholderKey) {
      placeholderKey = `#BIND_GROUP_LAYOUT_${this._nextFreeLayoutPlaceholderIdx++}#`;
      memoMap.set(layout, placeholderKey);
    }

    return placeholderKey;
  }

  allocateFixedEntry(
    layoutEntry: TgpuLayoutEntry,
    resource: object,
  ): { group: string; binding: number } {
    const binding = this.fixedBindings.length;
    this.fixedBindings.push({ layoutEntry, resource });

    return {
      group: CATCHALL_BIND_GROUP_IDX_MARKER,
      binding,
    };
  }

  readSlot<T>(slot: TgpuSlot<T>): T {
    const value = this._itemStateStack.readSlot(slot);

    if (value === undefined) {
      throw new MissingSlotValueError(slot);
    }

    return value;
  }

  withSlots<T>(pairs: SlotValuePair[], callback: () => T): T {
    if (pairs.length === 0) {
      return callback();
    }

    this._itemStateStack.pushSlotBindings(pairs);

    try {
      return callback();
    } finally {
      this._itemStateStack.pop('slotBinding');
    }
  }

  withVaryingLocations<T>(locations: Record<string, number>, callback: () => T): T {
    this._varyingLocations = locations;

    try {
      return callback();
    } finally {
      this._varyingLocations = undefined;
    }
  }

  withRenamed<T>(item: object, name: string | undefined, callback: () => T): T {
    if (!name) {
      return callback();
    }
    const oldName = getName(item);
    try {
      setName(item, name);
      return callback();
    } finally {
      if (oldName) {
        setName(item, oldName);
      }
    }
  }

  unwrap<T>(eventual: Eventual<T>): T {
    if (isProviding(eventual)) {
      return this.withRenamed(eventual[$providing].inner, getName(eventual), () =>
        this.withSlots(
          eventual[$providing].pairs,
          () => this.unwrap(eventual[$providing].inner) as T,
        ),
      );
    }

    let maybeEventual = eventual;

    // Unwrapping all layers of slots.
    while (true) {
      if (isSlot(maybeEventual)) {
        maybeEventual = this.readSlot(maybeEventual);
      } else if (isLazy(maybeEventual)) {
        maybeEventual = this._getOrCompute(maybeEventual);
      } else {
        break;
      }
    }

    return maybeEventual;
  }

  _getOrCompute<T>(lazy: TgpuLazy<T>): T {
    // All memoized versions of `lazy`
    const instances = this.#namespaceInternal.memoizedLazy.get(lazy) ?? [];

    this._itemStateStack.pushItem();

    try {
      for (const instance of instances) {
        const slotValuePairs = [...instance.slotToValueMap.entries()];

        if (
          slotValuePairs.every(([slot, expectedValue]) =>
            slot.areEqual(this._itemStateStack.readSlot(slot), expectedValue),
          )
        ) {
          return instance.result as T;
        }
      }

      // If we got here, no item with the given slot-to-value combo exists in cache yet
      // Getting out of codegen or simulation mode so we can execute JS normally.
      this.pushMode(new NormalState());

      let result: T;
      try {
        result = lazy[$internal].compute();
      } finally {
        this.popMode('normal');
      }

      // We know which slots the item used while resolving
      const slotToValueMap = new Map<TgpuSlot<unknown>, unknown>();
      for (const usedSlot of this._itemStateStack.topItem.usedSlots) {
        slotToValueMap.set(usedSlot, this._itemStateStack.readSlot(usedSlot));
      }

      instances.push({ slotToValueMap, result });
      this.#namespaceInternal.memoizedLazy.set(lazy, instances);
      return result;
    } catch (err) {
      if (err instanceof ResolutionError) {
        throw err.appendToTrace(lazy);
      }

      throw new ResolutionError(err, [lazy]);
    } finally {
      this._itemStateStack.pop('item');
    }
  }

  /**
   * @param item The item whose resolution should be either retrieved from the cache (if there is a cache hit), or resolved.
   */
  _getOrInstantiate(item: object): ResolvedSnippet {
    // All memoized versions of `item`
    const instances = this.#namespaceInternal.memoizedResolves.get(item) ?? [];

    this._itemStateStack.pushItem();

    try {
      for (const instance of instances) {
        const slotValuePairs = [...instance.slotToValueMap.entries()];

        if (
          slotValuePairs.every(([slot, expectedValue]) =>
            slot.areEqual(this._itemStateStack.readSlot(slot), expectedValue),
          )
        ) {
          return instance.result;
        }
      }

      // If we got here, no item with the given slot-to-value combo exists in cache yet
      let result: ResolvedSnippet;
      if (isData(item)) {
        // Ref is arbitrary, as we're resolving a schema
        result = snip(this.gen.emitTypeAnnotation(item), Void, /* origin */ 'runtime');
      } else if (isLazy(item) || isSlot(item)) {
        result = this.resolve(this.unwrap(item));
      } else if (isSelfResolvable(item)) {
        result = item[$resolve](this);
      } else if (hasTinyestMetadata(item)) {
        // Resolving a function with tinyest metadata directly means calling it with no arguments, since
        // we cannot infer the types of the arguments from a WGSL string.
        const shellless = this.#namespaceInternal.shelllessRepo.get(
          item,
          /* no arguments */ undefined,
        );
        if (!shellless) {
          throw new Error(
            `Couldn't resolve ${item.name}. Make sure it's a function that accepts no arguments, or call it from another TypeGPU function.`,
          );
        }

        return this.withResetIndentLevel(() => this.resolve(shellless));
      } else {
        throw new TypeError(`Unresolvable internal value: ${safeStringify(item)}`);
      }

      // We know which slots the item used while resolving
      const slotToValueMap = new Map<TgpuSlot<unknown>, unknown>();
      for (const usedSlot of this._itemStateStack.topItem.usedSlots) {
        slotToValueMap.set(usedSlot, this._itemStateStack.readSlot(usedSlot));
      }

      instances.push({ slotToValueMap, result });
      this.#namespaceInternal.memoizedResolves.set(item, instances);

      return result;
    } catch (err) {
      if (err instanceof ResolutionError) {
        throw err.appendToTrace(item);
      }

      throw new ResolutionError(err, [item]);
    } finally {
      this._itemStateStack.pop('item');
    }
  }

  resolve(item: unknown, schema?: BaseData | UnknownData): ResolvedSnippet {
    if (typeof item === 'string') {
      if (!schema || schema === UnknownData) {
        throw new Error(
          `Strings cannot be injected into WGSL directly (tried to inject '${item}'). Look for TypeGPU APIs that cover your use-case, or resort to using tgpu['~unstable'].rawCodeSnippet for raw code injection.`,
        );
      }
      // For example:
      // () => { 'use gpu'; const color = d.vec3f(); return color; }
      //                             snip('color', d.vec3f) ^^^^^
      return snip(item, schema, /* origin */ 'runtime');
    }

    if ((isTgpuFn(item) || isShelllessImpl(item)) && !isProviding(item)) {
      // We skip providing functions to only perform the checks on slot-less functions.
      if (
        this.#startedFunctionResolves.has(item) &&
        !this.#namespaceInternal.memoizedResolves.has(item)
      ) {
        throw new Error(
          `Recursive function ${item} detected. Recursion is not allowed on the GPU.`,
        );
      }
      this.#startedFunctionResolves.add(item as object);
    }

    if (isProviding(item)) {
      return this.withRenamed(item[$providing].inner, getName(item), () =>
        this.withSlots(item[$providing].pairs, () => this.resolve(item[$providing].inner, schema)),
      );
    }

    if (isMarkedInternal(item) || hasTinyestMetadata(item)) {
      // Top-level resolve
      if (this._itemStateStack.itemDepth === 0) {
        try {
          this.pushMode(new CodegenState());
          const result = provideCtx(this, () => this._getOrInstantiate(item));
          return snip(
            `${this._declarations.map((decl) => decl.code).join('\n\n')}${result.value}`,
            Void,
            /* origin */ 'runtime', // arbitrary
          );
        } finally {
          this.popMode('codegen');
        }
      }

      return this._getOrInstantiate(item);
    }

    // This is a value that comes from the outside, maybe we can coerce it
    if (typeof item === 'number') {
      const realSchema = schema ?? numericLiteralToSnippet(item).dataType;
      invariant(realSchema !== UnknownData, 'Schema has to be known for resolving numbers');

      return this.gen.numericLiteral(item, realSchema);
    }

    if (typeof item === 'boolean') {
      return snip(item ? 'true' : 'false', bool, /* origin */ 'constant', false);
    }

    if (schema && isWgslArray(schema)) {
      if (!Array.isArray(item)) {
        throw new WgslTypeError(`Cannot coerce ${item} into value of type '${schema}'`);
      }

      if (schema.elementCount !== item.length) {
        throw new WgslTypeError(
          `Cannot create value of type '${schema}' from an array of length: ${item.length}`,
        );
      }

      return this.gen.typeInstantiation(
        schema,
        item.map((element) => snip(element, schema.elementType, /* origin */ 'runtime')),
      );
    }

    if (schema && isWgslStruct(schema)) {
      return this.gen.typeInstantiation(
        schema,
        Object.entries(schema.propTypes).map(([key, propType]) =>
          snip((item as Infer<typeof schema>)[key], propType, /* origin */ 'runtime'),
        ),
      );
    }

    if (item === null) {
      throw new WgslTypeError(
        `'null' is not resolvable. 'null' is only allowed in comptime checks.`,
      );
    }

    throw new WgslTypeError(
      `Value ${safeStringify(item)} is not resolvable${
        schema && schema !== UnknownData ? ` to type ${safeStringify(schema)}` : ''
      }`,
    );
  }

  resolveSnippet(snippet: Snippet): ResolvedSnippet {
    return withValue(this.resolve(snippet.value, snippet.dataType).value, snippet);
  }

  pushMode(mode: ExecState) {
    this.#modeStack.push(mode);
  }

  popMode(expected?: ExecMode) {
    const mode = this.#modeStack.pop();
    if (expected !== undefined) {
      invariant(mode?.type === expected, 'Unexpected mode');
    }
  }

  get mode(): ExecState {
    return this.#modeStack[this.#modeStack.length - 1] ?? topLevelState;
  }
}

/**
 * A single module-scope declaration emitted during resolution.
 *
 * @property name - The resolved identifier the declaration declares (a fn, struct, var, const or
 *   alias name), or `undefined` for declarations that don't declare a single identifier (e.g.
 *   `tgpu['~unstable'].declare`).
 * @property code - The WGSL code of the declaration.
 */
export interface ResolvedDeclaration {
  name: string | undefined;
  code: string;
}

/**
 * The results of a WGSL resolution.
 *
 * @param code - The resolved code.
 * @param declarations - The module-scope declarations emitted by TypeGPU
 *  during this resolution, in emission order. When resolving an array without a
 *  template, `code` equals `declarations.map((d) => d.code).join('\n\n')` (unless extensions are enabled or minification is enabled).
 *  When resolving a template, the template itself is not included in `declarations`.
 *  With a shared namespace, only declarations emitted by *this* resolution are
 *  included (memoized ones are not re-emitted).
 * @param usedBindGroupLayouts - List of used `tgpu.bindGroupLayout`s.
 * @param catchall - Automatically constructed bind group for buffer usages and buffer bindings, preceded by its index.
 * @param logResources - Buffers and information about used console.logs needed to decode the raw data.
 * @param usedImmediate - The immediate variable used by the shader, if any.
 */
export interface ResolutionResult {
  code: string;
  declarations: ResolvedDeclaration[];
  usedBindGroupLayouts: TgpuBindGroupLayout[];
  catchall: [number, TgpuBindGroup] | undefined;
  logResources: LogResources | undefined;
  usedImmediate: TgpuImmediateVar | undefined;
}

export function resolve(item: Wgsl, options: ResolutionCtxImplOptions): ResolutionResult {
  const ctx = new ResolutionCtxImpl(options);
  const snippet = options.config
    ? ctx.withSlots(options.config(new ConfigurableImpl([])).bindings, () => ctx.resolve(item))
    : ctx.resolve(item);
  let code = snippet.value;

  const memoMap = ctx.bindGroupLayoutsToPlaceholderMap;
  const usedBindGroupLayouts: TgpuBindGroupLayout[] = [];
  const takenIndices = new Set<number>(
    [...memoMap.keys()].map((layout) => layout.index).filter((v): v is number => v !== undefined),
  );

  const automaticIds = naturalsExcept(takenIndices);

  const layoutEntries = ctx.fixedBindings.map(
    (binding, idx) => [String(idx), binding.layoutEntry] as [string, TgpuLayoutEntry],
  );

  // Bind group indices are only known now, so the same placeholder
  // replacements applied to `code` are recorded and re-applied to each
  // declaration's code.
  const bindingReplacements: [placeholder: string, index: string][] = [];

  const createCatchallGroup = () => {
    const catchallIdx = automaticIds.next().value;
    const catchallLayout = bindGroupLayout(Object.fromEntries(layoutEntries));
    usedBindGroupLayouts[catchallIdx] = catchallLayout;
    code = code.replaceAll(CATCHALL_BIND_GROUP_IDX_MARKER, String(catchallIdx));
    bindingReplacements.push([CATCHALL_BIND_GROUP_IDX_MARKER, String(catchallIdx)]);

    return [
      catchallIdx,
      new TgpuBindGroupImpl(
        // Undefined only in rootless `tgpu.resolve()`, where the group is never unwrapped
        options.root as ExperimentalTgpuRoot,
        catchallLayout,
        Object.fromEntries(
          // oxlint-disable-next-line typescript/no-explicit-any -- it's fine
          ctx.fixedBindings.map((binding, idx) => [String(idx), binding.resource] as [string, any]),
        ),
      ),
    ] as [number, TgpuBindGroup];
  };

  // Retrieving the catch-all binding index first, because it's inherently
  // the least swapped bind group (fixed and cannot be swapped).
  const catchall = layoutEntries.length > 0 ? createCatchallGroup() : undefined;

  for (const [layout, placeholder] of memoMap.entries()) {
    const idx = layout.index ?? automaticIds.next().value;
    usedBindGroupLayouts[idx] = layout;
    code = code.replaceAll(placeholder, String(idx));
    bindingReplacements.push([placeholder, String(idx)]);
  }

  if (options.enableExtensions && options.enableExtensions.length > 0) {
    const extensions = options.enableExtensions.map((ext) => `enable ${ext};`);
    code = `${extensions.join('\n')}\n\n${code}`;
  }

  let declarations = ctx.declarations.map(({ name, code: declarationCode }) => ({
    name,
    code: bindingReplacements.reduce(
      (acc, [placeholder, idx]) => acc.replaceAll(placeholder, idx),
      declarationCode,
    ),
  }));

  if (options.minify) {
    code = minify(code);
    // TODO(#2804): remove this workaround
    declarations = declarations.map((entry) => ({ ...entry, code: minify(entry.code) }));
  }

  return {
    code,
    declarations,
    usedBindGroupLayouts,
    catchall,
    logResources: ctx.logResources,
    usedImmediate: ctx.usedImmediate,
  };
}
