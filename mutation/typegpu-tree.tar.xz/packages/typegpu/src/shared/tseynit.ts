import * as tinyest from 'tinyest';

const { NodeTypeCatalog: NODE } = tinyest;

export function stringifyNode(node: tinyest.AnyNode): string {
  if (isExpression(node)) {
    return stringifyExpression(node);
  }

  return stringifyStatement(node, '');
}

function stringifyStatement(node: tinyest.Statement, indent: string): string {
  if (isExpression(node)) {
    return `${indent}${stringifyExpression(node)};`;
  }

  if (node[0] === NODE.block) {
    const statements = node[1].map((n) => stringifyStatement(n, indent + '  '));
    return `{\n${statements.join('\n')}\n${indent}}`;
  }

  if (node[0] === NODE.return) {
    const expr = node[1] === undefined ? '' : ` ${stringifyExpression(node[1])}`;
    return `${indent}return${expr};`;
  }

  if (node[0] === NODE.if) {
    const cond = stringifyExpression(node[1]);
    const then = stringifyStatement(node[2], indent);
    const base = `${indent}if (${cond}) ${then}`;
    if (node[3] !== undefined) {
      return `${base} else ${stringifyStatement(node[3], indent)}`;
    }
    return base;
  }

  if (node[0] === NODE.let) {
    const decl = `${indent}let ${stringifyExpression(node[1])}`;
    if (node[2] !== undefined) {
      return `${decl} = ${stringifyExpression(node[2])};`;
    }
    return `${decl};`;
  }

  if (node[0] === NODE.const) {
    const decl = `${indent}const ${stringifyExpression(node[1])}`;
    if (node[2] !== undefined) {
      return `${decl} = ${stringifyExpression(node[2])};`;
    }
    return `${decl};`;
  }

  if (node[0] === NODE.for) {
    const init = node[1] ? stringifyStatement(node[1], '') : ';';
    const cond = node[2] ? stringifyExpression(node[2]) : '';
    const update = node[3] ? stringifyStatement(node[3], '') : '';
    const body = stringifyStatement(node[4], indent);
    return `${indent}for (${init} ${cond}; ${update.slice(0, -1) /* trim the ';' */}) ${body}`;
  }

  if (node[0] === NODE.while) {
    const cond = stringifyExpression(node[1]);
    const body = stringifyStatement(node[2], indent);
    return `${indent}while (${cond}) ${body}`;
  }

  if (node[0] === NODE.continue) {
    return `${indent}continue;`;
  }

  if (node[0] === NODE.break) {
    return `${indent}break;`;
  }

  if (node[0] === NODE.forOf) {
    const leftKind = node[1][0] === NODE.const ? 'const' : 'let';
    const leftName = stringifyExpression(node[1][1]);
    const right = stringifyExpression(node[2]);
    const body = stringifyStatement(node[3], indent);
    return `${indent}for (${leftKind} ${leftName} of ${right}) ${body}`;
  }

  if (node[0] === NODE.switch) {
    const discriminant = stringifyExpression(node[1]);
    const cases = node[2].map((c) => {
      const test = c[0] === null ? 'default' : `case ${stringifyExpression(c[0])}`;
      if (c[1].length === 0) {
        return `${test}:`;
      }
      const consequents = c[1].map((s) => stringifyStatement(s, indent + '    '));
      return `${test}:\n${consequents.join('\n')}`;
    });
    return `${indent}switch (${discriminant}) {\n${cases.map((c) => `${indent + '  '}${c}`).join('\n')}\n${indent}}`;
  }

  assertExhaustive(node);
}

const JS_IDENTIFIER = /^[$_\p{ID_Start}][$_\u{200c}\u{200d}\p{ID_Continue}]*$/u;

function stringifyObjectPropertyKey(key: string): string {
  return JS_IDENTIFIER.test(key) ? key : JSON.stringify(key);
}

export function stringifyObjectProperty([key, value, computed]: tinyest.ObjectProperty): string {
  const keyStr = computed ? `[${stringifyExpression(key)}]` : stringifyObjectPropertyKey(key);
  const valueStr = stringifyExpression(value);
  return `${keyStr}: ${valueStr}`;
}

function stringifyExpression(node: tinyest.Expression): string {
  if (typeof node === 'string') {
    return node;
  }

  if (typeof node === 'boolean') {
    return `${node}`;
  }

  if (node[0] === NODE.identifier) {
    return node[1];
  }

  if (node[0] === NODE.booleanLiteral) {
    return `${node[1]}`;
  }

  if (node[0] === NODE.numericLiteral) {
    return node[1];
  }

  if (node[0] === NODE.stringLiteral) {
    return JSON.stringify(node[1]);
  }

  if (node[0] === NODE.arrayExpr) {
    const elements = node[1].map((n) => stringifyExpression(n));
    return `[${elements.join(', ')}]`;
  }

  if (node[0] === NODE.binaryExpr) {
    return `${wrapIfComplex(node[1])} ${node[2]} ${wrapIfComplex(node[3])}`;
  }

  if (node[0] === NODE.assignmentExpr) {
    return `${stringifyExpression(node[1])} ${node[2]} ${stringifyExpression(node[3])}`;
  }

  if (node[0] === NODE.logicalExpr) {
    return `${wrapIfComplex(node[1])} ${node[2]} ${wrapIfComplex(node[3])}`;
  }

  if (node[0] === NODE.unaryExpr) {
    // Unary word operators like void, instanceof and delete require a space
    const sep = node[1].length > 1 ? ' ' : '';
    return `${node[1]}${sep}${wrapIfComplex(node[2])}`;
  }

  if (node[0] === NODE.call) {
    const callee = wrapIfComplex(node[1]);
    const args = node[2].map((n) => stringifyExpression(n)).join(', ');
    return `${callee}(${args})`;
  }

  if (node[0] === NODE.memberAccess) {
    if (Array.isArray(node[1]) && node[1][0] === NODE.numericLiteral) {
      return `(${stringifyExpression(node[1])}).${stringifyExpression(node[2])}`;
    }
    return `${wrapIfComplex(node[1])}.${stringifyExpression(node[2])}`;
  }

  if (node[0] === NODE.indexAccess) {
    return `${wrapIfComplex(node[1])}[${stringifyExpression(node[2])}]`;
  }

  if (node[0] === NODE.preUpdate) {
    return `${node[1]}${wrapIfComplex(node[2])}`;
  }

  if (node[0] === NODE.postUpdate) {
    return `${wrapIfComplex(node[2])}${node[1]}`;
  }

  if (node[0] === NODE.objectExpr) {
    if (Array.isArray(node[1])) {
      return `{ ${node[1].map(stringifyObjectProperty).join(', ')} }`;
    }

    const entries = Object.entries(node[1]).map(
      ([key, val]) => `${stringifyObjectPropertyKey(key)}: ${stringifyExpression(val)}`,
    );
    return `{ ${entries.join(', ')} }`;
  }

  if (node[0] === NODE.conditionalExpr) {
    return `${wrapIfComplex(node[1])} ? ${wrapIfComplex(node[2])} : ${wrapIfComplex(node[3])}`;
  }

  if (node[0] === NODE.nullLiteral) {
    return 'null';
  }

  assertExhaustive(node);
}

function assertExhaustive(value: never): never {
  throw new Error(`'${JSON.stringify(value)}' was not handled by the stringify function.`);
}

function isExpression(node: tinyest.AnyNode): node is tinyest.Expression {
  if (
    typeof node === 'string' ||
    typeof node === 'boolean' ||
    node[0] === NODE.identifier ||
    node[0] === NODE.booleanLiteral ||
    node[0] === NODE.numericLiteral ||
    node[0] === NODE.stringLiteral ||
    node[0] === NODE.arrayExpr ||
    node[0] === NODE.binaryExpr ||
    node[0] === NODE.assignmentExpr ||
    node[0] === NODE.logicalExpr ||
    node[0] === NODE.unaryExpr ||
    node[0] === NODE.call ||
    node[0] === NODE.memberAccess ||
    node[0] === NODE.indexAccess ||
    node[0] === NODE.preUpdate ||
    node[0] === NODE.postUpdate ||
    node[0] === NODE.objectExpr ||
    node[0] === NODE.conditionalExpr ||
    node[0] === NODE.nullLiteral
  ) {
    node satisfies tinyest.Expression;
    return true;
  }
  node satisfies Exclude<tinyest.AnyNode, tinyest.Expression>;
  return false;
}

const SIMPLE_NODES: number[] = [
  NODE.memberAccess, // highest precedence
  NODE.indexAccess, // highest precedence
  NODE.call, // highest precedence
  NODE.arrayExpr, // [] make things not ambiguous
  NODE.stringLiteral,
  NODE.numericLiteral,
  NODE.identifier,
  NODE.booleanLiteral,
];
/**
 * Stringifies expression, and wraps it in parentheses if they cannot be trivially omitted
 */
function wrapIfComplex(node: tinyest.Expression): string {
  const s = stringifyExpression(node);
  if (typeof node === 'string' || typeof node === 'boolean') {
    return s;
  }
  if (SIMPLE_NODES.includes(node[0])) {
    return s;
  }
  return `(${s})`;
}
