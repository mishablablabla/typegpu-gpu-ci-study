// NOTE: This is a barrel file, internal files should not import things from this file

export * as d from './data/index.ts';
export * as std from './std/index.ts';
export * as common from './common/index.ts';

export {
  MissingBindGroupsError,
  MissingImmediatesError,
  MissingSlotValueError,
  MissingVertexBuffersError,
  NotUniformError,
  ResolutionError,
} from './errors.ts';
export { isAccessor, isLazy, isMutableAccessor, isSlot } from './core/slot/slotTypes.ts';
export { isComparisonSampler, isSampler } from './core/sampler/sampler.ts';
export { isTexture } from './core/texture/texture.ts';
export { isUsableAsRender, isUsableAsSampled } from './core/texture/usageExtension.ts';
export {
  isBuffer,
  isUsableAsUniform,
  isUsableAsVertex,
  isUsableAsIndex,
  isUsableAsStorage,
} from './types.ts';
export {
  isBufferBinding,
  isBufferShorthand,
  isMutableBinding,
  isReadonlyBinding,
  isUniformBinding,
} from './core/buffer/bufferBinding.ts';
export { isBindGroup, isBindGroupLayout } from './tgpuBindGroupLayout.ts';
export { isTgpuFn } from './core/function/tgpuFn.ts';
export { isTgpuFragmentFn } from './core/function/tgpuFragmentFn.ts';
export { isTgpuVertexFn } from './core/function/tgpuVertexFn.ts';
export { isTgpuComputeFn } from './core/function/tgpuComputeFn.ts';
export { isComputePipeline, isPipeline, isRenderPipeline } from './core/pipeline/typeGuards.ts';
export { isQuerySet } from './core/querySet/querySet.ts';
export { isVariable } from './core/variable/tgpuVariable.ts';
export { isVertexLayout } from './core/vertexLayout/vertexLayout.ts';
export { isImmediateVar } from './core/immediate/immediateVar.ts';
export type {
  /** @deprecated Import from 'typegpu/~internal' instead */ ShaderGenerator,
} from './tgsl/shaderGenerator.ts';
export {
  /** @deprecated Import from 'typegpu/~internal' instead */ WgslGenerator,
} from './tgsl/wgslGenerator.ts';
export { readFromArrayBuffer, writeToArrayBuffer } from './data/dataIO.ts';
export { patchArrayBuffer } from './data/partialIO.ts';
export { warn } from './tgpuLogger.ts';

// types

export type { ResolvableObject, ShaderStage } from './types.ts';
export type { ResolvedDeclaration } from './resolutionCtx.ts';
export type {
  Configurable,
  TgpuGuardedComputePipeline,
  TgpuRoot,
  ValidateBufferSchema,
  ValidateStorageSchema,
  ValidateUniformSchema,
  Withable,
  WithBinding,
} from './core/root/rootTypes.ts';
export type { Storage, StorageFlag } from './extension.ts';
export type { TgpuVertexLayout } from './core/vertexLayout/vertexLayout.ts';
export type { TgpuPrimitiveState, TgpuRenderPipeline } from './core/pipeline/renderPipeline.ts';
export type { ColorAttachment, DepthStencilAttachment } from './core/commandEncoder/attachments.ts';
export type { TgpuComputePipeline } from './core/pipeline/computePipeline.ts';
export type { TgpuCommandEncoder } from './core/commandEncoder/commandEncoder.ts';
export type {
  TgpuRenderBundleEncoder,
  TgpuRenderCommands,
  TgpuRenderPass,
  TgpuRenderPassDescriptor,
} from './core/commandEncoder/renderPass.ts';
export type {
  TgpuComputePass,
  TgpuComputePassDescriptor,
} from './core/commandEncoder/computePass.ts';
export type {
  IndirectFlag,
  IndexFlag,
  TgpuBuffer,
  Uniform,
  UniformFlag,
  UsageLiteral,
  ValidUsagesFor,
  Vertex,
  VertexFlag,
  TgpuStorageBuffer,
  TgpuUniformBuffer,
  TgpuVertexBuffer,
  TgpuIndexBuffer,
  BufferWriteOptions,
  BufferInitCallback,
  BufferInitialData,
} from './core/buffer/buffer.ts';
export type {
  TgpuBufferMutable,
  TgpuBufferReadonly,
  TgpuBufferUniform,
} from './core/buffer/bufferUsage.ts';
export type {
  TgpuBufferBinding,
  TgpuMutable,
  TgpuReadonly,
  TgpuUniform,
} from './core/buffer/bufferBinding.ts';
export type {
  Eventual,
  TgpuAccessor,
  TgpuLazy,
  TgpuMutableAccessor,
  TgpuSlot,
} from './core/slot/slotTypes.ts';
export type {
  RawCodeSnippetOrigin,
  TgpuRawCodeSnippet,
} from './core/rawCodeSnippet/tgpuRawCodeSnippet.ts';
export type { TgpuTexture, TgpuTextureView } from './core/texture/texture.ts';
export type {
  TextureBlobWriteOptions,
  TextureChannel,
  TextureCopyOptions,
  TextureRawWriteOptions,
  TextureWriteFit,
  TextureWriteOptions,
} from './core/texture/textureWrite.ts';
export type { TextureProps } from './core/texture/textureProps.ts';
export type { RenderFlag, SampledFlag } from './core/texture/usageExtension.ts';
export type { InitFromDeviceOptions, InitOptions } from './core/root/init.ts';
export type { TgpuConst } from './core/constant/tgpuConstant.ts';
export type { TgpuVar, VariableScope } from './core/variable/tgpuVariable.ts';
export type { TgpuImmediateVar } from './core/immediate/immediateVar.ts';
export type {
  TgpuComparisonSampler,
  TgpuFixedComparisonSampler,
  TgpuFixedSampler,
  TgpuSampler,
} from './core/sampler/sampler.ts';
export type { TgpuQuerySet } from './core/querySet/querySet.ts';
export type {
  ExtractBindGroupInputFromLayout,
  LayoutEntryToInput,
  TgpuBindGroup,
  TgpuBindGroupLayout,
  TgpuLayoutComparisonSampler,
  TgpuLayoutEntry,
  TgpuLayoutExternalTexture,
  TgpuLayoutSampler,
  TgpuLayoutStorage,
  TgpuLayoutTexture,
  TgpuLayoutUniform,
} from './tgpuBindGroupLayout.ts';
export type { TgpuFn, TgpuFnShell, TgpuGenericFn } from './core/function/tgpuFn.ts';
export type { TgpuComptime } from './core/function/comptime.ts';
export type { TgpuVertexFn, TgpuVertexFnShell } from './core/function/tgpuVertexFn.ts';
export type { TgpuFragmentFn, TgpuFragmentFnShell } from './core/function/tgpuFragmentFn.ts';
export type { TgpuComputeFn, TgpuComputeFnShell } from './core/function/tgpuComputeFn.ts';
export type {
  AnyAutoCustoms,
  /** @deprecated use TgpuFragmentFn.AutoIn */
  AutoFragmentIn,
  /** @deprecated use TgpuFragmentFn.AutoOut */
  AutoFragmentOut,
  /** @deprecated use TgpuVertexFn.AutoIn */
  _AutoVertexIn as AutoVertexIn,
  /** @deprecated use TgpuVertexFn.AutoOut */
  AutoVertexOut,
} from './core/function/autoIO.ts';
export type { TgpuDeclare } from './core/declare/tgpuDeclare.ts';
export type { Namespace } from './core/resolve/namespace.ts';
// Exported for being able to track use of these global extensions easier,
// and to establish a solid contract between tooling using them.
export type { INTERNAL_GlobalExt } from './shared/meta.ts';

/** @deprecated Use TgpuRenderPipeline.Descriptor */
export type TgpuRenderPipelineDescriptor =
  import('./core/pipeline/renderPipeline.ts').TgpuRenderPipeline.Descriptor;
