import { BufferWriter, getSystemEndianness } from 'typed-binary';
import { roundUp } from '../mathUtils.ts';
import { alignmentOf } from './alignmentOf.ts';
import { getCompiledWriter } from './compiledIO.ts';
import { writeData } from './dataIO.ts';
import { isDisarray, isUnstruct } from './dataTypes.ts';
import { offsetsForProps } from './offsets.ts';
import { sizeOf } from './sizeOf.ts';
import type * as wgsl from './wgslTypes.ts';
import { isWgslArray, isWgslStruct, type BaseData } from './wgslTypes.ts';
import type { InferPatch } from '../shared/repr.ts';

export interface WriteInstruction {
  data: Uint8Array<ArrayBuffer>;
  gpuOffset: number;
  /** How many bytes to upload. Can be larger than `data`, e.g. to cover trailing padding. */
  uploadSize: number;
}

/**
 * Converts `{idx, value}[]` sparse arrays into `Record<number, T>` format.
 */
export function convertPartialToPatch(schema: wgsl.BaseData, data: unknown): unknown {
  if (data === undefined || data === null) {
    return data;
  }

  if (isWgslStruct(schema) || isUnstruct(schema)) {
    const result: Record<string, unknown> = {};
    const record = data as Record<string, unknown>;
    for (const key of Object.keys(schema.propTypes)) {
      const subSchema = schema.propTypes[key];
      const value = record[key];
      if (value !== undefined && subSchema) {
        result[key] = convertPartialToPatch(subSchema, value);
      }
    }
    return result;
  }

  if (isWgslArray(schema) || isDisarray(schema)) {
    const arrSchema = schema as wgsl.WgslArray;
    const result: Record<number, unknown> = {};
    for (const { idx, value } of data as { idx: number; value: unknown }[]) {
      result[idx] = convertPartialToPatch(arrSchema.elementType, value);
    }
    return result;
  }

  return data;
}

const isLittleEndian = getSystemEndianness() === 'little';

interface Segment {
  start: number;
  end: number;
  padding?: number | undefined;
}

/**
 * @param validateRange Called for every byte range that is about to be written, before any data
 *   is written into `targetBuffer`. Returns how many bytes to upload for that range.
 *   Throwing from it leaves `targetBuffer` untouched.
 */
export function getPatchInstructions<TData extends wgsl.BaseData>(
  schema: TData,
  data: unknown,
  targetBuffer?: ArrayBuffer,
  validateRange?: (start: number, end: number) => number,
): WriteInstruction[] {
  const totalSize = sizeOf(schema);
  if (totalSize === 0 || data === undefined || data === null) {
    return [];
  }

  const buf = targetBuffer ?? new ArrayBuffer(totalSize);
  const writer = new BufferWriter(buf);
  const compiledView = new DataView(buf);

  const segments: Segment[] = [];
  // Deferred until every range is validated
  const pendingWrites: (() => void)[] = [];

  function collect(node: wgsl.BaseData, value: unknown, offset: number, padding?: number) {
    if (value === undefined || value === null) {
      return;
    }

    if (isWgslStruct(node) || isUnstruct(node)) {
      const propOffsets = offsetsForProps(node);
      for (const [key, propOffset] of Object.entries(propOffsets)) {
        const childValue = (value as Record<string, unknown>)[key];
        const subSchema = node.propTypes[key];
        if (childValue !== undefined && subSchema) {
          collect(subSchema, childValue, offset + propOffset.offset, propOffset.padding ?? padding);
        }
      }
      return;
    }

    if (isWgslArray(node) || isDisarray(node)) {
      const arrSchema = node as wgsl.WgslArray;
      const elementSize = roundUp(
        sizeOf(arrSchema.elementType),
        alignmentOf(arrSchema.elementType),
      );
      const elementPadding = elementSize - sizeOf(arrSchema.elementType);

      if (ArrayBuffer.isView(value)) {
        const copyLen = Math.min(value.byteLength, arrSchema.elementCount * elementSize);
        pendingWrites.push(() => {
          new Uint8Array(buf, offset, copyLen).set(
            new Uint8Array(value.buffer, value.byteOffset, copyLen),
          );
        });
        segments.push({ start: offset, end: offset + copyLen, padding });
        return;
      }

      if (Array.isArray(value)) {
        for (let i = 0; i < Math.min(arrSchema.elementCount, value.length); i++) {
          collect(arrSchema.elementType, value[i], offset + i * elementSize, elementPadding);
        }
        return;
      }

      const sparse = value as Record<string, unknown>;
      for (const key of Object.keys(sparse)) {
        const idx = Number(key);
        if (!Number.isNaN(idx)) {
          collect(arrSchema.elementType, sparse[key], offset + idx * elementSize, elementPadding);
        }
      }
      return;
    }

    const leafSize = sizeOf(node);
    const compiledWriter = getCompiledWriter(node);
    pendingWrites.push(() => {
      if (compiledWriter) {
        compiledWriter(compiledView, offset, value, isLittleEndian, offset + leafSize);
      } else {
        writer.seekTo(offset);
        writeData(writer, node, value);
      }
    });
    segments.push({ start: offset, end: offset + leafSize, padding });
  }

  collect(schema, data, 0);

  const runs: Segment[] = [];
  let run: Segment | null = null;

  for (const seg of segments) {
    if (run && seg.start === run.end + (run.padding ?? 0)) {
      run = { start: run.start, end: seg.end, padding: seg.padding };
    } else {
      if (run) {
        runs.push(run);
      }
      run = seg;
    }
  }
  if (run) {
    runs.push(run);
  }

  const uploads = runs.map(({ start, end }) => ({
    start,
    end,
    uploadSize: validateRange?.(start, end) ?? end - start,
  }));

  for (const write of pendingWrites) {
    write();
  }

  return uploads.map(({ start, end, uploadSize }) => ({
    gpuOffset: start,
    data: new Uint8Array(buf, start, end - start).slice(),
    uploadSize,
  }));
}

export function patchArrayBuffer<T extends BaseData>(
  buffer: ArrayBuffer,
  schema: T,
  data: InferPatch<T>,
) {
  const instructions = getPatchInstructions(schema, data, buffer);
  const mappedView = new Uint8Array(buffer);
  for (const { data, gpuOffset } of instructions) {
    mappedView.set(data, gpuOffset);
  }
}
