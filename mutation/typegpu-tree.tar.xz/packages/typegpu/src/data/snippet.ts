import { undecorate } from './dataTypes.ts';
import type { UnknownData } from './dataTypes.ts';
import { DEV } from '../shared/env.ts';
import { type BaseData, isNumericSchema } from './wgslTypes.ts';

export type Origin =
  // --- ADDRESS SPACE ORIGINS
  | 'uniform' /*   defined in the 'uniform' address space  */
  | 'readonly' /*  defined in the 'storage' address space, with 'read' access  */
  | 'mutable' /*   defined in the 'storage' address space, with 'read-write' access  */
  | 'workgroup' /* defined in the 'workgroup' address space  */
  | 'private' /*   defined in the 'private' address space  */
  | 'handle' /*    defined in the 'handle' address space  */
  | 'immediate' /* defined in the 'immediate' address space  */
  | 'function' /*  defined in a callee, passed down to us as an argument ('function' address space)  */
  // --- DEFINITIONS
  // defined in the current function
  | 'local-def'
  // A reference to a deeply immutable definition, recognized by WGSL as a 'constant'.
  // This is the usual case, read about 'runtime-immutable-def' to know when this doesn't apply.
  // A reference to a tgpu.const().$ value (which is frozen) fits into this category.
  | 'constant-immutable-def'
  // A reference to a deeply immutable definition, NOT recognized by WGSL as a 'constant'.
  // This can happen if say a constant is accessed with a runtime-known index. WGSL doesn't treat it like
  // a 'constant' anymore, but it's still a frozen value in JS, so we must treat it like it's immutable.
  | 'runtime-immutable-def'
  // ---------
  // non-pointer function arguments (or part of an argument).
  | 'argument'
  // not a reference to anything, known at runtime
  | 'runtime'
  // an ephemeral value that is a valid WGSL 'constant' (not to be confused with 'comptime')
  // doesn't always lead to creating a `const` variable, as we cannot always guarantee that
  // the value won't be mutated in JS
  | 'constant';

/**
 * What happens to a snippet's origin when it's deep copied in JS, and left as is in WGSL?
 * e.g. `vec3f(vec3f(0, 1, 2))`
 */
export function fallthroughCopyOrigin(origin: Origin): Origin {
  if (
    origin === 'runtime' || // runtime values stay runtime
    origin === 'constant' // constant values stay constant
  ) {
    // The origin is kept as-is
    return origin;
  }
  // All other origins become runtime
  return 'runtime';
}

/**
 * Whether a snippet refers to a value already stored in memory.
 *
 * @example
 * ```ts
 * function foo(a: number) {
 *   'use gpu';
 *   const color = d.vec3f(1, 2, 3);
 *   return color * a;
 * }
 *
 * // Stored in memory:
 * // -  color
 * // -  a
 * //
 * // Ephemeral values:
 * // - d.vec3f(1, 2, 3)
 * // - color * a
 * ```
 */
export function isStoredInMemory(snippet: Snippet) {
  return !(snippet.origin === 'runtime' || snippet.origin === 'constant');
}

export const originToPtrParams = {
  uniform: { space: 'uniform', access: 'read' },
  immediate: { space: 'immediate', access: 'read' },
  readonly: { space: 'storage', access: 'read' },
  mutable: { space: 'storage', access: 'read-write' },
  workgroup: { space: 'workgroup', access: 'read-write' },
  private: { space: 'private', access: 'read-write' },
  function: { space: 'function', access: 'read-write' },
  // Local declarations are also in the `function` address space
  'local-def': { space: 'function', access: 'read-write' },
} as const;
export type OriginToPtrParams = typeof originToPtrParams;

/**
 * Whether values of this origin can have their address taken.
 */
export function isAddressableOrigin(origin: Origin): origin is keyof OriginToPtrParams {
  return origin in originToPtrParams;
}

/**
 * Whether values of this origin can be mutated.
 */
export function isMutableOrigin(origin: Origin): boolean {
  return isAddressableOrigin(origin) && originToPtrParams[origin].access === 'read-write';
}

export interface Snippet {
  readonly value: unknown;
  /**
   * The type that `value` is assignable to (not necessary exactly inferred as).
   * E.g. `1.1` is assignable to `f32`, but `1.1` itself is an abstract float
   */
  readonly dataType: BaseData | UnknownData;
  readonly origin: Origin;
  /**
   * A snippet has possible side effects either if we're sure that it has side
   * effects, or if our systems are unable to reliably determine that it
   * doesn't have side effects.
   *
   * A snippet has side-effects if executing the WGSL code within and not using
   * the return value is not equivalent to just not executing the WGSL code at
   * all, with a margin of executing a few more instructions. For example, code
   * that mutates memory, or synchronizes threads, has side effects.
   */
  readonly possibleSideEffects: boolean;
}

export interface ResolvedSnippet extends Snippet {
  readonly value: string;
  readonly dataType: BaseData;
}

export type MapValueToSnippet<T> = { [K in keyof T]: Snippet };

class SnippetImpl implements Snippet {
  readonly value: unknown;
  readonly dataType: BaseData | UnknownData;
  readonly origin: Origin;
  readonly possibleSideEffects: boolean;

  constructor(
    value: unknown,
    dataType: BaseData | UnknownData,
    origin: Origin,
    possibleSideEffects: boolean,
  ) {
    this.value = value;
    this.dataType = dataType;
    this.origin = origin;
    this.possibleSideEffects = possibleSideEffects;
  }
}

export function isSnippet(value: unknown): value is Snippet {
  return value instanceof SnippetImpl;
}

export function isSnippetNumeric(snippet: Snippet) {
  return isNumericSchema(snippet.dataType);
}

export function snip(
  value: string,
  dataType: BaseData,
  origin: Origin,
  possibleSideEffects?: boolean,
): ResolvedSnippet;
export function snip(
  value: unknown,
  dataType: BaseData | UnknownData,
  origin: Origin,
  possibleSideEffects?: boolean,
): Snippet;
export function snip(
  value: unknown,
  dataType: BaseData | UnknownData,
  origin: Origin,
  possibleSideEffects: boolean = true,
): Snippet | ResolvedSnippet {
  if (DEV && isSnippet(value)) {
    // An early error, but not worth checking every time in production
    throw new Error('Cannot nest snippets');
  }

  return new SnippetImpl(
    value,
    // We don't care about attributes in snippet land, so we discard that information.
    undecorate(dataType as BaseData),
    origin,
    possibleSideEffects,
  );
}

export function withDataType(
  dataType: BaseData | UnknownData,
  snippet: ResolvedSnippet,
): ResolvedSnippet;
export function withDataType(dataType: BaseData | UnknownData, snippet: Snippet): Snippet;
export function withDataType(dataType: BaseData | UnknownData, snippet: Snippet): Snippet {
  return new SnippetImpl(snippet.value, dataType, snippet.origin, snippet.possibleSideEffects);
}

export function withValue(value: string, snippet: Snippet): ResolvedSnippet;
export function withValue(value: unknown, snippet: Snippet): Snippet;
export function withValue(value: unknown, snippet: Snippet): Snippet {
  return new SnippetImpl(value, snippet.dataType, snippet.origin, snippet.possibleSideEffects);
}

export function withSideEffects(
  possibleSideEffects: boolean,
  snippet: ResolvedSnippet,
): ResolvedSnippet;
export function withSideEffects(possibleSideEffects: boolean, snippet: Snippet): Snippet;
export function withSideEffects(possibleSideEffects: boolean, snippet: Snippet): Snippet {
  return new SnippetImpl(snippet.value, snippet.dataType, snippet.origin, possibleSideEffects);
}

export function noSideEffects(snippet: ResolvedSnippet): ResolvedSnippet;
export function noSideEffects(snippet: Snippet): Snippet;
export function noSideEffects(snippet: Snippet): Snippet {
  return withSideEffects(/* possibleSideEffects */ false, snippet);
}
